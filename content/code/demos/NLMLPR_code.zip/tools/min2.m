function [M, I1, I2] = min2(mat)
%MIN2        Minimum of a 2D array
%   M = MIN2(MAT) gives the mimimum value M of the 2D array MAT.
%   [M, I1, I2] = MIN2(MAT) gives the mimimum value M of the 2D
%   array MAT and its corresponding indices I1, I2 in MAT:
%
%               MAT(I1, I2) = M = MIN2(MAT)
%
%   See also max2, mean2, sum2
%
%   Copyright (C) 2011 NLM-SAP project
%   Charles Deledalle, Vincent Duval, Joseph Salmon
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-SAP.
%
%   NLM-SAP is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-SAP is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-SAP.  If not, see
%   <http://www.gnu.org/licenses/>.

[m, It] = min(mat);
[M, I2] = min(m);
I1 = It(I2);

end
