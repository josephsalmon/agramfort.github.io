%% Simple example on Swoosh
%
% We present here the following methods for Local Polynomial Regression (LPR)
% in the case of 
%  
% -Linear Filter (LF) 
%
% -Yaroslavksy's filter (YF) 
%
% -Non-Local Means (NLM)
%
% -Non-Local Means-Average (NLMA)
%
% -Membership oracle (MO) 
%
%
% The kernel used is the box kernel. 
% See also README.TXT in the associate zip file for
% more details.
%
% See DEMO_NLMLPR.m
%

%% Initialization
close all
clear all
addpath('tools');
addpath('functions');

%% Build the true and noisy images
sigma=50;
ima = mean(double(imread('data/swoosh.png')),3);
ima_nse = ima + sigma * randn(size(ima));

%% Parameters initialization
param.patch_width=7;
param.search_width=15;

param.h_NLM=3.5*param.patch_width*param.patch_width*sigma^2;       
%param.h_OYF=900;% 
%param.h_YF=10*(sigma)^2;%
%param.h_NLMA=4*sigma^2/(param.patch_width)^2;


%% Compute the NLM-LPR estimations for \(r=0,1,2\)
tic
ima_fil_NLM0=NLM0(ima_nse,param.h_NLM,param.search_width,param.patch_width);
ima_fil_NLM1=NLM1(ima_nse,param.h_NLM,param.search_width,param.patch_width);
ima_fil_NLM2=NLM2(ima_nse,param.h_NLM,param.search_width,param.patch_width);

% Other methods:
% LF         :  ima_fil_LF0=LF0(ima_nse,param.search_width); 
% YF         :  ima_fil_YF0=YF1(ima_nse,param.h_YF,param.search_width); 
% NLMA       :  ima_fil_NLMA0=NLM2(ima_nse,param.h_NLMA,param.search_width,param.patch_width); 
% Oracle YF  :  ima_fil_OYF0=OYF2(ima,ima_nse,param.h_OYF,param.search_width); 

%%  Total time
toc

%% Display result
figure('Position',[100 100  700 700])

subplot(2,2,1)
plotimage(ima_nse);
title('Noisy');
set(get(gca,'Title'),'FontSize',16);
subplot(2,2,2);
plotimage(ima_fil_NLM0);
title('Estimate with NLM and r=0');
set(get(gca,'Title'),'FontSize',16);
subplot(2,2,3);
plotimage(ima_fil_NLM1);
title('Estimate with NLM and r=1');
set(get(gca,'Title'),'FontSize',16);
subplot(2,2,4);
plotimage(ima_fil_NLM2);
title('Estimate with NLM and r=2');
set(get(gca,'Title'),'FontSize',16);

linkaxes
