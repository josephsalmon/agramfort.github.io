NLM Local Polynomial Regression (NLM-LPR)
====================================

Revision:	        12/19/2011
Author:                 E. Arias-Castro, J. Salmon, R. Willet
Web page:               http://josephsalmon.org/code/index_codes.php?page=NLMLPR

NLM-LPR is a MATLAB software implementing the denoising algorithm NLM
Local Polynomial Regression (NLM-LPR) for images damaged by Gaussian noise
as presented in:


NLM-LPR is free software distributed under the GNU Public License
(GPL). NLM-LPR should be used only for nonprofit purposes. Any
unauthorized use of this software for industrial or profit-oriented
activities is expressively prohibited.

LICENSE
=======

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

See LICENSE.txt

HOW TO
======

The program has been written for MATLAB with the ImageProcessing
Toolbox and the Statistics Toolbox. Please, look at DEMO_NLMLPR_online.m
to use the standard version of NLM, NLMA, YF, LF  and the (membership)
oracle (also called Oracle YF).

MAIN PROGRAM FILES
==================

The main program files are the following:

- DEMO_NLMLPR_online.m :
	A demonstration file illustrating our denoising algorithms.

-LF0, LF1, LF2: Linear filter of order 0,1 and 2

-YF0, YF1, YF2: Yaroslavky's Filter of order 0,1 and 2

-OYF0, OYF1,  OYF2: Oracle Yaroslavsky Filter of order 0,1 and 2

-NLM0, NLM1,  NML2: Non Local Means of order 0,1 and 2


CONTACT INFORMATION
===================

For any comment, suggestion or question please contact Ery Arias-Castro
Joseph Salmon or Rebecca Willett.

Ery Arias-Castro		eariasca (at) ucsd.edu
Joseph Salmon			joseph.salmon (at) duke.edu
Rebecca Willett	                willett (at) duke.edu
Copyright (C) 2011 NLM-LPR project

See The GNU Public License (GPL) in LICENSE.txt

