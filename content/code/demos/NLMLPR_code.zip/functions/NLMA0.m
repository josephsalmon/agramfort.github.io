function  Im_NLMA= NLMA0(Im_noisy,h,search_width,patch_width)

% Non Local Means - Average with LPR of order 0: the distance
% between patches is only measured through the distances
% between the mean of the patches.
%   INPUT:
%     Im_noisy         : Noisy image
%     h		       : photometric bandwidth
%     search_width     : width of the searching zone 
%			 (size= search_width x search_width)
%     patch_width      : witdth of th patch 
%			 (size=patch_width x patch_width)
%   OUTPUT:
%     Im_NLMA           : Denoised image based using NLM-Average 
%                         and LPR or order 0
%
%   Im_NLMA = NLMA0(Im_noisy,h,search_width,patch_width)
%   computes the linear filter or order 0, using the box-kernel. 
%
%   See also NLMA1, NLMA2 and YF, NLM etc.
%
%   Copyright (C) 2011 NLM-LPR project
%   Ery Arias-Castro, Joseph Salmon, Rebecca Willett.
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-LPR.
%
%   NLM-LPR is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-LPR is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-LPR.  If not, see
%   <http://www.gnu.org/licenses/>.


[N, M] = size(Im_noisy);
Im_NLMA = zeros(N, M);
radius = (search_width - 1) / 2;
radius_patch=(patch_width - 1) / 2;
Im_noisy_big = EdgeMirror(Im_noisy, [radius+radius_patch, radius+radius_patch]);
Xx = ones(search_width^2,1);
weights=zeros(search_width^2,1);

for n = (1+radius_patch) : (N+radius_patch) 
    for m = (1+radius_patch) : (M+radius_patch)   
        
        Part_Im_noisy=Im_noisy_big(n:n+search_width-1, m:m+search_width-1);        
        Intermed=Im_noisy_big(n+radius-radius_patch:n+radius+radius_patch,m+radius-radius_patch:m+radius+radius_patch);
        
        for delta_n=-radius:radius
            for delta_m=-radius:radius
                
            weights((delta_n+radius+1)+(delta_m+radius)*(search_width))=( sum(sum(Im_noisy_big(n+radius-radius_patch+delta_n:n+radius+radius_patch+delta_n,...
                m+radius-radius_patch+delta_m:m+radius+radius_patch+delta_m)-Intermed)))/patch_width^2;   
  
            end
        end
        
        W=(weights(:).^2<h);
        Xw = Xx(W,1);                            
        A = (Xx(W,:)' * Xw  )\(Xw');        
        Im_NLMA(n-radius_patch,m-radius_patch)   = A(1,:) * Part_Im_noisy(W);
    end
end


