function Im_box_kernel = LF1(Im_noisy,search_width)

%Linear Filtering of order 1        
%   INPUT:
%     Im_noisy         : Noisy image
%     search_width     : width of the searching zone 
%			 (size= search_width x search_width)
%   OUTPUT:
%     Im_box_kernel      : Denoised image based on LPR or order 0
%
%   Im_box_kernel = LF1(Im_noisy,search_width)
%   computes the linear filter or order 1, using the box-kernel. 
%
%   See also Im_box_kernel0,Im_box_kernel1 and YF, NLM etc.
%
%   Copyright (C) 2011 NLM-LPR project
%   Ery Arias-Castro, Joseph Salmon, Rebecca Willett.
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-LPR.
%
%   NLM-LPR is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-LPR is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-LPR.  If not, see
%   <http://www.gnu.org/licenses/>.

[N, M] = size(Im_noisy);
Im_box_kernel = zeros(N, M);
radius = (search_width - 1) / 2;
[x2, x1] = meshgrid(-radius: radius, -radius: radius);
Im_noisy = EdgeMirror(Im_noisy, [radius, radius]);
Xx = [ones(search_width^2,1), x1(:), x2(:)];

for n = 1 : N   
    for m = 1 : M      
        Part_Im_noisy=Im_noisy(n:n+search_width-1, m:m+search_width-1);
        
        Xw = [Xx(:,1), Xx(:,2), Xx(:,3)];
        A = (Xx' * Xw +1e-8*eye(3) )\(Xw');       
        Im_box_kernel(n,m)   = A(1,:) * Part_Im_noisy(:);
    end
end

