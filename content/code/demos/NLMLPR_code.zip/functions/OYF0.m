function Im_Yaro_oracle = OYF0(Im_ori,Im_noisy,h,search_width)
%Oracle/Yaroslavsky type of order 0        
%   INPUT:
%     Im_noisy         : Noisy image
%     search_width     : width of the searching zone 
%			 (size= search_width x search_width)
%     h		       : oracle photometric bandwidth
%   OUTPUT:
%     Im_Yaro_oracle      : Denoised image based on LPR or order 0
%
%   Im_Yaro_oracle = OYF0(Im_ori,Im_noisy,h,search_width)
%   computes the linear filter or order 0, using the box-kernel. 
%
%   See also OYF1, OYF2 and YF, NLM etc.
%
%   Copyright (C) 2011 NLM-LPR project
%   Ery Arias-Castro, Joseph Salmon, Rebecca Willett.
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-LPR.
%
%   NLM-LPR is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-LPR is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-LPR.  If not, see
%   <http://www.gnu.org/licenses/>.

[N, M] = size(Im_ori);
Im_Yaro_oracle = zeros(N, M);
radius = (search_width - 1) / 2;
Im_ori = EdgeMirror(Im_ori, [radius, radius]);
Im_noisy = EdgeMirror(Im_noisy, [radius, radius]);
Xx = ones(search_width^2,1);

for n = 1 : N  
    for m = 1 : M   
        Part_Im_noisy=Im_noisy(n:n+search_width-1, m:m+search_width-1);        
        Part_Im_ori=Im_ori(n:n+search_width-1, m:m+search_width-1);
        W=find((Part_Im_ori-Im_ori(n+radius,m+radius)).^2<h);        
        Xw = Xx(W,1);                            
        A = (Xx(W,:)' * Xw  )\(Xw');        
        Im_Yaro_oracle(n,m)   = A(1,:) * Part_Im_noisy(W);
    end
end


