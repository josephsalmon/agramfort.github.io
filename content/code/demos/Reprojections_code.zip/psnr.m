function res=psnr(x,y)

d = mean( (x(:)-y(:)).^2 );
%m = max( max(x(:)),max(y(:)))
res = 10*log10( 255^2/d );
