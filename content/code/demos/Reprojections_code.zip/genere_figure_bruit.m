
function [I,IB1,IB2]=genere_figure_bruit(cas,sigma)

%   Authors:  Salmon, Strozecki  
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-Reprojections.
%
%   NLM-Reprojections is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-Reprojections is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-Reprojections.  If not, see
%   <http://www.gnu.org/licenses/>.

switch cas
    
    case 1
        I=imread('images/barbara.png');
    case 2
        I=imread('images/boat.png');
    case 3
        I=imread('images/bridge.png');
    case 4
        I=imread('images/cameraman.png');     
    case 5
        I=imread('images/couple.png');
    case 6
        I=imread('images/fingerprint.png');
    case 7
        I=imread('images/flinstones.png');
    case 8
        I=imread('images/hill.png');
    case 9
        I=imread('images/house.png');
    case 10
        I=imread('images/lena.png');
    case 11
        I=imread('images/man.png');   
    case 12
        I=imread('images/peppers256.png');
    case 13
       %%%% edge 
        I=zeros(256,256);
        I(129:end,1:end)=255;   
    case 14
        I=imread('images/chessboard.png');
   
    case 15
       %%%% corner
       I=zeros(256,256);
       I(129:end,129:256)=255;   
    case  16   
       I=255*ones(256,256);
       I=triu(I);
    case  17   
       I=ones(256,1)*(1:256);
    case  18   
       I=ones(256,256)*128;    
    case  19  
        I=zeros(256,256);
        I(:,128:159)=8*ones(256,1)*(1:32);          
    case  20  
        I=zeros(1024,1024);
        I(:,1:512)=255*ones(1024,512);          
    case 21
        I=imread('images/mandrill_gray.png');               
    case  22  
        I=zeros(256,256);
        I(131:138,131:138)=255;       
end

[n,m]=size(I);
I=double(I);
Br1=randn(n,m)*sigma;
IB1=I+Br1;
Br2=randn(n,m)*sigma;
IB2=I+Br2; 

