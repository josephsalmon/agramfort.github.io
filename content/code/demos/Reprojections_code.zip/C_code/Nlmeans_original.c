/*The original NLmeans with an exponetial kernel*/
/* Authors : Salmon, Strozecki*/
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "mex.h"

/*There are two ways to deal with access by the algorithm of pixels which are out of the image.
If type=1, the image is considered to be toric. If  type=2, a symmetry along each border of the image is performed.
*/
int bord(int pos, int limite, int type)
{
    if (pos >= 0 && pos <= limite-1)    
    {   
        return pos;    
    }
    else   
    {           
        switch (type)
        {
            case 1 :               
                if (pos<0)	    
                {	      
                    return (limite+pos);	    
                }
                else	    
                {	      
                    return(pos-limite);	    
                }	
            case 2 :	  
                if (pos < 0)	    
                {	      
                    return (-(pos+1));	    
                }
                else
                {
                    return (2*limite-pos-1);    
                }
	        
        }
    
    }
}


/* This function extracts from the matrix Mat (of size Mat_x times Mat_y) the submatrix
 of size (l times l) starting from (i,j) and writes it in the vector Vect */
void extract_vector_from_matrix(int i, int j, int l, double* Mat, double* Vect, int Max_x, int Max_y, int type)
{  
    int p,q;
    for ( p=0;p<l;p++)
    {
        for (q=0;q<l;q++)
        {	
        Vect[p+l*q]=Mat[bord(i+p,Max_x,type) + (bord(j+q, Max_y,type))*Max_x];        
        }
    }
}


/*This function computes the distance between two patches divided by the size of the patches*/
double distance(double* X, double* Y,int n)
{ 
    double dist = 0;
    double temp = 0;  
    int i;  
    for (i=0;i<n;i++)
    { 
        temp = X[i]-Y[i];      
        dist += temp*temp;   
    }   
    return (dist/n);
}

/* The main function, which corrects the image given by entree and outputs it in sortie*/
/* The integer x_lim and y_lim are the dimensions of the image*/
void correction(double* entree, double* sortie, int x_lim, int y_lim, int largeur_recherche, int largeur_patch, double inv_h, double seuil, int type)
{  
  
    double d;
    double moins_inv_h=-inv_h;
    int cote_patch = 2*largeur_patch +1; /*the width of the patch*/
    int dim = cote_patch*cote_patch;
    int centre =  largeur_patch*(cote_patch+1);
    double* patch;
    double*patch_courant;
    patch=malloc(dim*sizeof(double));
    patch_courant=malloc(dim*sizeof(double));
    double coeff,valeur_pixel,normalisation;
    coeff=0;
    int i,j,p,q;
    for( i=0; i<x_lim; i++)    
      {    
        for( j = 0; j < y_lim;j++)	
	  {           
            /* We correct the pixel of coordinate (i,j)*/
            
            extract_vector_from_matrix((i-largeur_patch), (j-largeur_patch), cote_patch, entree, patch, x_lim, y_lim, type);
            valeur_pixel =0 ;
            normalisation = 0;            
            
            for( p = (-largeur_recherche); p <= largeur_recherche; p++)            
	      {             
		for( q = (-largeur_recherche); q <= largeur_recherche; q++)           
		  {
		    extract_vector_from_matrix(i+p-largeur_patch, j+q-largeur_patch, cote_patch, entree, patch_courant, x_lim, y_lim, type);		  
		    d = distance(patch,patch_courant,dim);
		    /*Here we test every patch in the search zone, centered in (i+p,j+q). We use a patch to correct the pixel (i,j) if its distance is less than seuil*/		  
                    if (d <= seuil && d>= (-1))		    
		      {		      
			coeff = exp(d*moins_inv_h);	/*The kernel is exponential*/	      
                        valeur_pixel += patch_courant[centre]*coeff;
                        normalisation += coeff;		    
		      }	
		  }	   
	      }	
            sortie[i + j*x_lim] = (valeur_pixel/normalisation);	
	  }   
      }
}
		    

/*The function to interface with Mathlab*/


void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
     
{  
    double *entree;
    double *sortie ;
    double  inv_h; 
    int r1, x_lim,y_lim, w1, type;
    double seuil;    
    entree =(double*)mxGetPr(prhs[0]);
    w1 = mxGetScalar(prhs[1]);
    r1 = mxGetScalar(prhs[2]);
    inv_h  = mxGetScalar(prhs[3]);
    seuil = mxGetScalar(prhs[4]);
    type = mxGetScalar(prhs[5]);    
    x_lim = mxGetM(prhs[0]);
    y_lim = mxGetN(prhs[0]);

    	
    plhs[0] = mxCreateNumericMatrix(x_lim, y_lim, mxDOUBLE_CLASS, mxREAL);  
    sortie = (double*) mxGetData(plhs[0]);
    
    
    correction(entree,sortie, x_lim, y_lim, r1, w1, inv_h, seuil, type);
    
}




