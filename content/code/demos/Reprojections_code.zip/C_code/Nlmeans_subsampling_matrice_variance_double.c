/* An improvement of the classical NLmeans method, through a better reprojection
with a precomputation to speed up the algorithm*/
/* Authors : Salmon, Strozecki*/
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "mex.h"



int max(int a, int b)
{
    return (a>=b?a:b);
}

int min(int a, int b)
{
    return (a<=b?a:b);
}

int division(int a,int b)
{
    return(2*(a%b)>b?(a/b +1):(a/b));
}
      /* */

void alea(int* X, int taille, int range)
{
    int i;
    for(i=0;i<taille;i++)
    {
        X[i] = rand()%range;
    }
}


void affiche(int* X, int x, int y )
{
    int i,j;
    printf("\n");
    for( i=0;i<x;i++)
    {
        printf("\n");
        for(j=0;j<y;j++)
        {
            printf("| %d",X[j*x + i]);
        }
    }
}

void dinitialise(double* X,int dim)
{
    int i;
    for(i =0; i<dim;i++)
    {
        X[i] = 0;
    }
}


/*The three next functions give us all distances from a patch and the patch translated by (delta_x,delta_y). */
/*This method is used to increase the speed of the computation.   */

void difference(double* entree, double* mat_dif,int x_lim, int y_lim, int delta_x, int delta_y)
{
    int delta = delta_x + delta_y*x_lim;
    int pos,i,j;
    for( j= max(0,-delta_y); j< min(y_lim-delta_y,y_lim); j++)
    {
        for(i= max(0,-delta_x); i< min(x_lim-delta_x,x_lim); i++)
        {
            pos = i + j*x_lim;
            mat_dif[pos+2+j+x_lim]= entree[pos]-entree[pos+delta];
        }
    }
}



void precalcul(double* entree,int x_lim, int y_lim)
{
    double temp =0;
    int pos,i,j;
    for(j=x_lim;j<x_lim*y_lim;j=j+x_lim)
    {
        for(i=1;i<x_lim;i++)
        {
            pos = i+j;
            temp += entree[pos]*entree[pos];
            entree[pos] = (temp + entree[pos-x_lim]);
        } 
        temp = 0;
    }
}



void distance(double* matrice_distance, int x_lim,int y_lim,int cote_patch)
{
    int x1,y1,i,j;
    int cote_patch_large = cote_patch*x_lim;
    for(j=0;j<x_lim*(y_lim-cote_patch);j=j+x_lim) 
    {
        for(i=0;i<x_lim-cote_patch;i++)
        {
            x1 = i+cote_patch;
            y1 = j+cote_patch_large;
            matrice_distance[i+j] += matrice_distance[x1+y1] - matrice_distance[x1+j] - matrice_distance[i+y1];
        }
    }
}


/* This function is called when we have found that the patches (i0,j0) and (i0+p,j0+q) are similar */
/* We use the patch (i0,j0) to build the estimator of (i0+p,j0+q) and vice versa */

void update(double* entree, double* sortie, double* matrice_normalisation,int cote_patch,int x_lim,int i0,int j0,int p,int q)
{
    int i,j,pos1,pos2;
    for( j = 0;j<cote_patch*x_lim;j+=x_lim)
    {
        for(i = 0;i<cote_patch;i++)
        {
            pos1 = i+j+i0+j0;
            pos2 = i0+i+j0+j+p+q;
            sortie[pos1] += entree[pos2];
            matrice_normalisation[pos1]++;
            
            if(q!=0)            
            {
                sortie[pos2] += entree[pos1];
                matrice_normalisation[pos2]++;
            }

        }

    }

}


/* The main function, which corrects the image given by entree_ress and entree_av (useful for iteration of the method, in most cases equal) and outputs it in sortie*/
/* The integer x_lim and y_lim are the dimensions of the image*/
/* The integer cote_patch is half the width of the patch and demi_largeur_recherche is half the width of the search zone.*/
/* The parameter sample determines how much position of a pixel in a patch will be used to build the estimator of the pixel.
/* By default, it should be set to 1 and it should never be higher than cote_patch*/
void correction(double* entree_av,double* entree_ress, double* sortie,double* matrice_normalisation, int x_lim, int y_lim, int demi_largeur_recherche, int cote_patch, double seuil,int sample)
{  
  double normalisation;
  int i,j,p,q;
  int dim1 = x_lim*y_lim;
  int dim2 = (x_lim+1)*(y_lim+1);
  double* matrice_distance;
  double seuil_adapte = seuil*cote_patch*cote_patch;
  matrice_distance = malloc(dim2*sizeof(double));
  dinitialise(matrice_normalisation,dim1);
  dinitialise(matrice_distance,dim2);

  for(p = (-demi_largeur_recherche); p <= demi_largeur_recherche; p++)
    {   
      for(q = (-demi_largeur_recherche); q <=0; q++)	
        {
	  difference(entree_ress,matrice_distance,x_lim,y_lim,p,q);	  
	  precalcul(matrice_distance,x_lim+1,y_lim+1);	  
	  distance(matrice_distance,x_lim+1,y_lim+1,cote_patch);
	  /* Here we have all distances of the patches translated by (p,q) in matrice_distance)*/
	  /* We use them to build a partial estimator for each of these patches*/
	  for( i=max(0,-p); i<min(x_lim-p-cote_patch,x_lim-cote_patch)+1; i+=sample)
            {
	      for( j = max(0,-q); j < min(y_lim-q-cote_patch,y_lim-cote_patch)+1;j+=sample)
                {                
		  if (matrice_distance[i+(x_lim+1)*j] <= seuil_adapte)
                    {
		      update(entree_av,sortie,matrice_normalisation,cote_patch,x_lim,i,j*x_lim,p,q*x_lim);		                      
                    }		
                }	    
            }	              
	  dinitialise(matrice_distance,dim2);      
        }      
    }  
  for( i=0; i< dim1;i++)    
    {    
      if (matrice_normalisation[i] == 0)        
	sortie[i]=entree_av[i];    /* because of the subsampling, some points may be not processed, we use the original value in this case*/
      else    
	sortie[i]= sortie[i]/matrice_normalisation[i]; 
    }
}


		    


/*The function to interface with Mathlab*/
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    double *entree_av;
    double *entree_ress;
    double *sortie;
    double *matrice_normalisation;
    int r1, x_lim,y_lim, w,sample;
    double   seuil;
    entree_av =(double*)mxGetPr(prhs[0]);
    entree_ress=(double*)mxGetPr(prhs[1]);
    w = mxGetScalar(prhs[2]);
    r1 = mxGetScalar(prhs[3]);
    seuil = mxGetScalar(prhs[4]);
    sample=mxGetScalar(prhs[5]);
    x_lim = mxGetM(prhs[0]);
    y_lim = mxGetN(prhs[0]);



    plhs[0] = mxCreateNumericMatrix(x_lim, y_lim, mxDOUBLE_CLASS, mxREAL);
    sortie = (double*) mxGetData(plhs[0]);

    plhs[1] = mxCreateNumericMatrix(x_lim, y_lim, mxDOUBLE_CLASS, mxREAL);
    matrice_normalisation = (double*) mxGetData(plhs[1]);


    correction(entree_av,entree_ress,sortie,matrice_normalisation, x_lim, y_lim, r1, w, seuil,sample);    
}


