/* An improvement of the classical NLmeans method, through a better reprojection*/
/* Authors : Salmon, Strozecki*/
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "mex.h"


int max(int a, int b)
{
    return (a>=b?a:b);
}


int min(int a, int b)
{
    return (a<=b?a:b);
}


void dinitialise(double* X,int dim)
{ 
    int i;  
    for(i =0; i<dim;i++)    
    {
        X[i] = 0;
    }
}



double distance(double* X, int i0, int j0, int dx, int dy, int x_lim, int cote_patch)
{
    int i,j;
    double temp =0;
    for(j = j0*x_lim;j<x_lim*(j0+cote_patch);j+=x_lim)
    {
        for(i = i0;i<i0+cote_patch;i++)   
        {      
            temp += (X[i+j]-X[i+j+dx+dy*x_lim])*(X[i+j]-X[i+j+dx+dy*x_lim]);   
        }   
    }
    return temp;
}


/*This function changes the value of patch_val, which is then used to correct a whole patch. */
void update(double* patch_val, double* entree, int i0, int j0, int cote_patch, int x_lim)
{
    int i,j;
    for(i = 0;i<cote_patch;i++)       
    {
        for( j = 0;j<cote_patch;j++)
        {        
            patch_val[i+j*cote_patch] += entree[i0+i+(j0+j)*x_lim];
        }      
    }
}

/*We store the best candidate to correct the patch in sortie, if we have found a better candidate (patch_val), we update sortie*/
void  meilleure_correction(double* sortie,double* matrice_normalisation,double* patch_val,int normalisation,int i0,int j0,int cote_patch,int x_lim)
{
    int pos,i,j;   
    for( i = 0;i<cote_patch;i++) 
    {    
        for(j = 0;j<cote_patch;j++)        
        {        
            pos = i0+i+(j0+j)*x_lim;          
            if(normalisation > matrice_normalisation[pos])           
            {            
                matrice_normalisation[pos] = normalisation;              
                sortie[pos]= patch_val[i+j*cote_patch];
            }        
        }       
    }
}




/* The main function, which corrects the image given by entree and outputs it in sortie*/
/* The integer x_lim and y_lim are the dimensions of the image*/
/* The integer cote_patch is half the width of the patch and demi_largeur_recherche is half the width of the search zone.*/
void correction(double* entree, double* sortie, int x_lim, int y_lim, int demi_largeur_recherche, int cote_patch, double seuil)
{
 
    int normalisation,i,j,p,q;
    double* patch_val;
    double* matrice_normalisation;
    int dim;
    int dim2;
    
    dim=cote_patch*cote_patch;
    dim2=x_lim*y_lim;
    patch_val= malloc(dim*sizeof(double));
    matrice_normalisation= malloc(dim2*sizeof(double));
    dinitialise(matrice_normalisation,x_lim*y_lim);

    for( i=0; i<x_lim-cote_patch+1; i++)
    {        
        for( j = 0; j < y_lim-cote_patch+1;j++)
        {     
	  /* We correct the pixel of coordinate (i,j)*/
            dinitialise(patch_val,cote_patch*cote_patch);        
            normalisation = 0;        
            for( p = max(-i,-demi_largeur_recherche); p <= min(demi_largeur_recherche, x_lim-i-cote_patch); p++)        
            {         
                for( q = max(-j,-demi_largeur_recherche); q <= min(demi_largeur_recherche,y_lim-j-cote_patch); q++)        
                {        
                    if (distance(entree,i,j,p,q,x_lim,cote_patch) <= seuil*cote_patch*cote_patch)        
                    {        
                        update(patch_val,entree,i+p,j+q,cote_patch,x_lim);
                        normalisation ++;        
		    }        
                }       /*Here we have built an estimator with a flat kernel of the patch with top left corner (i,j)*/ 
		/* The estimator is the mean of all patches in the search zone of distance less than seuil*cote_patch*cote_patch to the current patch*/
            }        
            meilleure_correction(sortie,matrice_normalisation,patch_val,normalisation,i,j,cote_patch,x_lim);
	    /* For each pixel of the patch, we replace it by the pixel of the new estimator if it is better than the previous 
	       (it has been built from more patches)*/		
        }    
    }  
    for( i=0; i< x_lim*y_lim;i++)    
    {   
        sortie[i]= (sortie[i]/matrice_normalisation[i]); 
    }
}

		    

/*The function to interface with Mathlab*/


void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
     
{  
    double *entree;
    double *sortie ;
    int r1, x_lim,y_lim, w1, type;
	double seuil;    
    entree =(double*)mxGetPr(prhs[0]);
    w1 = mxGetScalar(prhs[1]);
    r1 = mxGetScalar(prhs[2]);
    seuil = mxGetScalar(prhs[3]);   
    x_lim = mxGetM(prhs[0]);
    y_lim = mxGetN(prhs[0]);
    
    
    
    
    plhs[0] = mxCreateNumericMatrix(x_lim, y_lim, mxDOUBLE_CLASS, mxREAL);  
    sortie = (double*) mxGetData(plhs[0]);

    
    
    correction(entree,sortie, x_lim, y_lim, r1, w1, seuil);
       
}
