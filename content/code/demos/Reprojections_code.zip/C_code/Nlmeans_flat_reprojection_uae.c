/* An improvement of the classical NLmeans method, through a better reprojection*/
/* Authors : Salmon, Strozecki*/
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "mex.h"


int max(int a, int b)
{
    return (a>=b?a:b);
}


int min(int a, int b)
{
    return (a<=b?a:b);
}

void dinitialise(double* X,int dim)
{ 
    int i;  
    for(i =0; i<dim;i++)    
    {
        X[i] = 0;
    }
}

/*This function computes the distance between a patch whose top left corner is (i0,j0) and the patch whose top left corner is (i0+dx,j0+dy)*/
double distance(double* X, int i0, int j0, int dx, int dy, int x_lim, int cote_patch)
{
    int i,j;
    double temp =0;
    for(j = j0*x_lim;j<x_lim*(j0+cote_patch);j+=x_lim)
    {
        for(i = i0;i<i0+cote_patch;i++)   
        {      
            temp += (X[i+j]-X[i+j+dx+dy*x_lim])*(X[i+j]-X[i+j+dx+dy*x_lim]);   
        }   
    }
    return temp;
}




/*This function changes the value of patch_val, which is then used to correct a whole patch.  */
void update(double* patch_val, double* entree, int i0, int j0, int cote_patch, int x_lim)
{

    int i,j;  
    for(i = 0;i<cote_patch;i++)
    {    
        for( j = 0;j<cote_patch;j++)	
        {	  
            patch_val[i+j*cote_patch] += entree[i0+i+(j0+j)*x_lim];
        }
    }
}


/* Update matrice_normalisation, such that we remember that a patch more have been selected to correct the patch 
with top left corner (i0,j0) */
void update_normalisation(double* matrice_normalisation, int i0, int j0, int cote_patch, int x_lim)
{
    int i,j;
    for(i = 0;i<cote_patch;i++)
    {
        for( j = 0;j<cote_patch;j++)
        {
            matrice_normalisation[i+j*cote_patch]+=1 ;
        }
    }
}

/*Correct the patch with top left corner (i0,j0) and store the number of patches used for this operation in nb_estimateur */
void  moyenne_correction(double* sortie,double* patch_val,double* matrice_normalisation,double* nb_estimateur,int i0,int j0,int cote_patch,int x_lim)
{
    int pos,i,j;
    for( i = 0;i<cote_patch;i++)
    {
        for(j = 0;j<cote_patch;j++)
        {
            pos = i0+i+(j0+j)*x_lim;            
            sortie[pos]+= (patch_val[i+j*cote_patch]/(matrice_normalisation[i+j*cote_patch]));
            nb_estimateur[pos]+=1;
            
        }
    }
}


/* The main function, which corrects the image given by entree and outputs it in sortie*/
/* The integer x_lim and y_lim are the dimensions of the image*/
void correction(double* entree, double* sortie, int x_lim, int y_lim, int demi_largeur_recherche, int cote_patch_int, double seuil)
{

    int i,j,p,q;
    int dim;
    dim=x_lim*y_lim;
    int dim2;
    dim2=cote_patch_int*cote_patch_int; 

    double* nb_estimateur;
    double* patch_val;
    double* matrice_normalisation;

    nb_estimateur=malloc(dim*sizeof(double));
    patch_val=malloc(dim2*sizeof(double));
    matrice_normalisation=malloc(dim2*sizeof(double));

    dinitialise(nb_estimateur,x_lim*y_lim);

    for( i=0; i<x_lim-cote_patch_int+1; i++)  
      {
        for( j = 0; j < y_lim-cote_patch_int+1;j++)
	  {
	   /* We correct the pixel of coordinate (i,j)*/
            dinitialise(patch_val,cote_patch_int*cote_patch_int);	 
            dinitialise(matrice_normalisation,cote_patch_int*cote_patch_int);	  
            for( p = max(-i,-demi_largeur_recherche); p <= min(demi_largeur_recherche, x_lim-i-cote_patch_int); p++)	    
	      { 
                for( q = max(-j,-demi_largeur_recherche); q <= min(demi_largeur_recherche,y_lim-j-cote_patch_int); q++)
		  {
                    if (distance(entree,i,j,p,q,x_lim,cote_patch_int) <= seuil*cote_patch_int*cote_patch_int)		   
		      {
                        update(patch_val,entree,i+p,j+q,cote_patch_int,x_lim);             
                        update_normalisation(matrice_normalisation,i+p,j+q,cote_patch_int,x_lim);			
		      }	
		  }	   
	      }         
            moyenne_correction(sortie,patch_val,matrice_normalisation,nb_estimateur,i,j,cote_patch_int,x_lim);
	    /*Here a whole patch is corrected, we modify sortie and store the fact that we have corrected each pixel
	      of the patch in nb_estimateur*/
	  }    
      }  
    for( i=0; i< x_lim*y_lim;i++) 
      {
        sortie[i]= sortie[i]/(nb_estimateur[i]); /* We divide sortie by the number of estimators used to build each of its pixels*/    
      }
}

		    
		    
/*The function to interface with Mathlab*/

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    double *entree;
    double *sortie;
    int r1, x_lim,y_lim, w;
    double   seuil;
    entree =(double*)mxGetPr(prhs[0]);
    w = mxGetScalar(prhs[1]);
    r1 = mxGetScalar(prhs[2]);
    seuil = mxGetScalar(prhs[3]);  
    x_lim = mxGetM(prhs[0]);
    y_lim = mxGetN(prhs[0]);


    plhs[0] = mxCreateNumericMatrix(x_lim, y_lim, mxDOUBLE_CLASS, mxREAL);
    sortie = (double*) mxGetData(plhs[0]);

    correction(entree,sortie, x_lim, y_lim, r1, w, seuil);    
}


