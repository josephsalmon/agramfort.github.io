function sortie=patch_deux_un(I,r1,i0,j0,cas)

%   Authors:  Salmon, Strozecki  
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-Reprojections.
%
%   NLM-Reprojections is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-Reprojections is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-Reprojections.  If not, see
%   <http://www.gnu.org/licenses/>.

[x_lim,y_lim]=size(I);
sortie=zeros((2*r1+1)^2,2);



switch cas

    case 1
%%%% patch center: columnwise order
    
    cote_patch_x=2;
    cote_patch_y=1;
        %rows
        for p=max(-i0+1,-r1):min(r1,x_lim-cote_patch_x-i0)
    
            % columns

            for q = max(-j0+1,-r1): min(r1,y_lim-cote_patch_y-j0)
   
               
                sortie(p+r1+1+(q+r1)*(2*r1+1),:)=[I(i0+p,j0+q),I(i0+p+1,j0+q)];
    
            end

        end



    case 2
%%%%%%% patche center :  rowise order


    cote_patch_x=1;
    cote_patch_y=2;
        %rows
        for p=max(-i0+1,-r1):min(r1,x_lim-cote_patch_x-i0)
    
            %columns

            for q = max(-j0+1,-r1): min(r1,y_lim-cote_patch_y-j0)
   
               
                sortie(p+r1+1+(q+r1)*(2*r1+1),:)=[I(i0+p,j0+q),I(i0+p,j0+q+1)];
    
            end

        end


end

