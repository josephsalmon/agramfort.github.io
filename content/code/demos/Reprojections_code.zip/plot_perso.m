function []=plot_perso(I,titre)

colormap('gray');
imagesc(I);
title(titre);
axis off