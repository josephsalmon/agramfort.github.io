%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% 	Matlab codes for Wav-Reprojections :       %%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   Authors:  Salmon, Strozecki  
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-Reprojections.
%
%   NLM-Reprojections is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-Reprojections is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-Reprojections.  If not, see
%   <http://www.gnu.org/licenses/>.



%Notice: this code creates the results in the following folder. Images 
% created are .eps format.

clear all
close all
mkdir('results')
name_directory_win='results/';


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  Clusters on the edge                              %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

legende={'Noisy Patches','True Patches','Central Patch'}
hXLabel = '';
hYLabel = '';
taille_font=19; 
taille_figure=[300 300 700 700];
figure_name='patches_space';
titre='';
scatter_patch=figure('Name','fig_en');
v=axis;
v(1)=-100;
v(2)=350;
v(3)=-100;
v(4)=350;
axis(v);



sigma=20;
r1=10;
[I,IB1]=genere_figure_bruit(13,sigma);
cas=1;
i0=128;
j0=128;


vecteur_double_bruit=patch_deux_un(IB1,r1,i0,j0,cas);
vecteur_double_ori=patch_deux_un(I,r1,i0,j0,cas);

figure(1)
hold on
scatter(vecteur_double_bruit(:,1),vecteur_double_bruit(:,2),40,'.');
scatter(vecteur_double_ori(:,1),vecteur_double_ori(:,2),100,'+','red');

switch cas
    case 1
        scatter(I(i0,j0),I(i0+1,j0),1000,'x','black');

    case 2
        scatter(I(i0,j0),I(i0,j0+1),500,'x','black');

end
hold off
legende_choix=2
sortie_eps
filename=strcat(name_directory_win,'black_white_closeup.png');
imwrite(IB1(i0-r1:i0+r1,j0-r1:j0+r1),gray(256),filename)

close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%        Cluster house			            %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

legende={'Noisy Patches','True Patches','Central Patch'}
hXLabel = '';
hYLabel = '';
taille_font=19;

figure_name='patches_space_house_goutiere';
titre='';
scatter_patch=figure('Name','fig_en');
v=axis;
v(1)=0;
v(2)=270;
v(3)=0;
v(4)=270;
axis(v);


sigma=20;
r1=10;
R=2*r1+1;
[I,IB1]=genere_figure_bruit(9,sigma);
cas=1;
i0=200;
j0=200;



vecteur_double_bruit=patch_deux_un(IB1,r1,i0,j0,cas);
vecteur_double_ori=patch_deux_un(I,r1,i0,j0,cas);

figure(1)
hold on
scatter(vecteur_double_bruit(:,1),vecteur_double_bruit(:,2),40,'.');
scatter(vecteur_double_ori(:,1),vecteur_double_ori(:,2),100,'+','red');

switch cas
    case 1
        scatter(I(i0,j0),I(i0+1,j0),1000,'x','black');
    case 2
        scatter(I(i0,j0),I(i0,j0+1),500,'x','black');
end

hold off
legende_choix=2;
sortie_eps


filename=strcat(name_directory_win,'house_closeup.png');
imwrite(IB1(i0-r1:i0+r1,j0-r1:j0+r1),gray(256),filename)


close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%%%%%   Cameraman  Close-up: Double size vs Original NL-Means   %%%%      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        

% Image loading
sigma=20;
[I,IB1]=genere_figure_bruit(4,sigma);
r1=10;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%   Original (Gaussian) NL-Means    %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

h=1*sigma^2; %%%  kernel bandwith
w1=4;        %%%  half size of patch 
seuil=1000000; %%% for eliminating too distant patches
bord=2;  %%% symmetric world
R2=Nlmeans_original(IB1,w1,r1,1/h,seuil,bord);
[n1,n2]=size(I);
R2=reshape(R2,n1,n2);

% results:
psnr(R2,I)
filename2=strcat(name_directory_win,'cameraman_closeup_gaussien_central.png');
imwrite(double(R2(45:100,100:155)),gray(256),filename2)
                         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                         
%%%%%%%%%%%% Wav-reprojection two size of patches  %%%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

w_big=9;
w_small=2;  
seuil1=1/(w_big)^2*qchisq(0.99,(w1)^2)*(2*sigma^2);   
seuil2=1/(w_small)^2*qchisq(0.75,(2)^2)*2*sigma^2;
   
[nl1,normalisation1]=Nlmeans_subsampling_matrice_variance_double(IB1,IB1,w_big,r1,seuil1,1);
[nl2,normalisation2]=Nlmeans_subsampling_matrice_variance_double(IB1,IB1,w_small,r1,seuil2,1);

R=(normalisation1/w_big.*nl1+nl2.*normalisation2/w_small)./(normalisation1/w_big+normalisation2/w_small);
psnr(R,I) 
filename3=strcat(name_directory_win,'cameraman_closeup_reprojection_wav_double.png');
imwrite(double(R(45:100,100:155)),gray(256),filename3)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%             Cameraman     images                   %%%%%%%%%%%%%                       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       
sigma=20;
[I,IB1]=genere_figure_bruit(4,sigma);         
r1=4;


imwrite(I,gray(256),strcat(name_directory_win,'cameraman_original.png'))
imwrite(IB1,gray(256),strcat(name_directory_win,'cameraman_noisy.png'))
psnr(IB1,I)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%     Flat kernel and central reprojection     %%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

w1=4; %%% beware here w=2*w1+1;
seuil=1/(2*w1+1)^2*qchisq(0.99,(2*w1+1)^2)*(2*sigma^2);
R2=Nlmeans_flat(IB1,w1,r1,seuil,2);
psnr(R2,I)
filename1=strcat(name_directory_win,'cameraman_flat_central_sig20_w_9_r1_9.png');
imwrite(R2,gray(256),filename1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%      Gaussian kernel central reprojection     %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
h=1*sigma^2;
w1=4;
seuil=1000000;
bord=2; %%% 1: toric, 2:symmetric world
R2=Nlmeans_original(IB1,w1,r1,1/h,seuil,bord);
toc
psnr(R2,I)
filename2=strcat(name_directory_win,'cameraman_nlm_original_sig20_w_9_r1_9.png');
imwrite(R2,gray(256),filename2)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%   		Uae-reprojection		%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
w1=9;
seuil=1/(w1)^2*qchisq(0.99,(w1)^2)*(2*sigma^2);
R2=Nlmeans_flat_reprojection_uae(IB1,w1,r1,seuil);
psnr(R2,I)
filename3=strcat(name_directory_win,'cameraman_flat_reprojection_uae_sig20_w_9_r1_9.png');
imwrite(R2,gray(256),filename3)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%   		Min-reprojection		%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

seuil=1/(w1)^2*qchisq(0.99,(w1)^2)*(2*sigma^2);
R2=Nlmeans_flat_reprojection_mini(IB1,w1,r1,seuil);
psnr(R2,I)
filename4=strcat(name_directory_win,'cameraman_diff_flat_reprojection_min_sig20_w_9_r1_9.png');
imwrite(R2,gray(256),filename4);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%   		Wav-reprojection		%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

seuil=1/(w1)^2*qchisq(0.99,(w1)^2)*(2*sigma^2);
R2=Nlmeans_subsampling_matrice_variance_double(IB1,IB1,w1,r1,seuil,1);
psnr(R2,I)


filename5=strcat(name_directory_win,'cameraman_diff_flat_reprojection_wav_sig20_w_9_r1_9.png');
imwrite(R2,gray(256),filename5)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%     Wav-reprojection with two size of patches		     %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

w_big=9;
w_small=2;  
seuil1=1/(w_big)^2*qchisq(0.99,(w_big)^2)*(2*sigma^2);   
seuil2=1/(w_small)^2*qchisq(0.75,(w_small)^2)*2*sigma^2;
   
[nl1,normalisation1]=Nlmeans_subsampling_matrice_variance_double(IB1,IB1,w_big,r1,seuil1,1);
[nl2,normalisation2]=Nlmeans_subsampling_matrice_variance_double(IB1,IB1,w_small,r1,seuil2,1);

R2=(normalisation1/w_big.*nl1+nl2.*normalisation2/w_small)./(normalisation1/w_big+normalisation2/w_small);
psnr(R2,I) 

filename6=strcat(name_directory_win,'cameraman_diff_flat_reprojection_wav_double_passe_sig20_w_9_r1_9.png');
imwrite(R2,gray(256),filename6)

close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%%%%%%%%%%%%%%    Toy Image:    simple Edge    %%%%%%%%%%%%%%%%%%%%%        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        


sigma=20;
[I,IB1]=genere_figure_bruit(13,sigma);         
r1=10;
imwrite(I,gray(256),strcat(name_directory_win,'black_white_original.png'))
imwrite(IB1,gray(256),strcat(name_directory_win,'black_white_noisy.png'))
psnr(IB1,I)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%%%%%%%%    Flat kernel and central reprojection   %%%%%%%%%%%%%%%%%        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        


w1=4; %%% beware here w=2*w1+1;
seuil=1/(2*w1+1)^2*qchisq(0.99,(2*w1+1)^2)*(2*sigma^2);
R2=Nlmeans_flat(IB1,w1,r1,seuil,2);
psnr(R2,I)
filename1=strcat(name_directory_win,'black_white_flat_central_sig20_w_9_r1_21.png');
delta=abs(R2-I);
imwrite(50*delta,gray(256),filename1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%   Gaussian kernel and central reprojection        %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
h=1*sigma^2;
w1=4;
seuil=1000000;
bord=2;%%% 1: toric, 2:symmetric world
R2=Nlmeans_original(IB1,w1,r1,1/h,seuil,bord);
psnr(R2,I)
filename2=strcat(name_directory_win,'black_white_nlm_original_sig20_w_9_r1_21.png');
delta=abs(R2-I);
imwrite(50*delta,gray(256),filename2);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%   			Uae reprojection 	              %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


w1=9;
seuil=1/(w1)^2*qchisq(0.99,(w1)^2)*(2*sigma^2);
R2=Nlmeans_flat_reprojection_uae(IB1,w1,r1,seuil);
psnr(R2,I)
filename3=strcat(name_directory_win,'black_white_flat_reprojection_uae_sig20_w_9_r1_21.png');
delta=abs(R2-I);
imwrite(50*delta,gray(256),filename3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%   			Min reprojection 	              %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


w1=9;
seuil=1/(w1)^2*qchisq(0.99,(w1)^2)*(2*sigma^2);
R2=Nlmeans_flat_reprojection_mini(IB1,w1,r1,seuil);
psnr(R2,I)
filename4=strcat(name_directory_win,'black_white_diff_flat_reprojection_min_sig20_w_9_r1_21.png');
delta=abs(R2-I);
imwrite(50*delta,gray(256),filename4);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%   			Wav reprojection 	              %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


w1=9;
seuil=1/(w1)^2*qchisq(0.99,(w1)^2)*(2*sigma^2);
R2=Nlmeans_subsampling_matrice_variance_double(IB1,IB1,w1,r1,seuil,1);
psnr(R2,I)

filename5=strcat(name_directory_win,'black_white_diff_flat_reprojection_wav_sig20_w_9_r1_21.png');
delta=abs(R2-I);
imwrite(50*delta,gray(256),filename5);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%   Wav reprojection with two  size of patches      %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


w_big=9;
w_small=2;  
seuil1=1/(w_big)^2*qchisq(0.99,(w_big)^2)*(2*sigma^2);   
seuil2=1/(w_small)^2*qchisq(0.75,(w_small)^2)*2*sigma^2;
   
[nl1,normalisation1]=Nlmeans_subsampling_matrice_variance_double(IB1,IB1,w_big,r1,seuil1,1);
[nl2,normalisation2]=Nlmeans_subsampling_matrice_variance_double(IB1,IB1,w_small,r1,seuil2,1);

R2=(normalisation1/w_big.*nl1+nl2.*normalisation2/w_small)./(normalisation1/w_big+normalisation2/w_small);
psnr(R2,I) 
toc

filename6=strcat(name_directory_win,'black_white_diff_flat_reprojection_wav_double_passe_sig20_w_9_r1_21.png');
delta=abs(R2-I);
imwrite(50*delta,gray(256),filename6);




close all                




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%    Toy Image: simple Edge  ;  theoretical psnr    %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear psnr_or_center
clear psnr_or_mini
n=256;
w=9;
w1=4
r1=10
R=21;
sigma=20;

somme_mini=0;
somme_center=0;


for i=1:((R-1)/2)
    somme_mini=somme_mini+1/(R*(R-i));
end

for j=1:((w+1)/2)
    somme_center=somme_center+1/(R*(R-j));
end

mse_or_effet_taille_patch=(sigma^2/(R^2))*(1-(R-1)/n) +(2/n)*somme_mini*sigma^2;
mse_or_center=(sigma^2/(R^2))*(1-(R-1)/n)+sigma^2*(w-1)/(n*R)+(2/n)*somme_center*sigma^2;

psnr_or_center=10*log10(255^2/mse_or_center)    
psnr_or_effet_taille_patch=10*log10(255^2/mse_or_effet_taille_patch)


[I,IB1]=genere_figure_bruit(13,sigma);
seuil=1/(w)^2*qchisq(0.99,(w)^2)*(2*sigma^2);
 
bord=2; %%% 1: toric, 2:symmetric world

estim_reproj_central=Nlmeans_flat(IB1,w1,r1,seuil,2);
psnr_center=psnr(estim_reproj_central,I)

estim_reproj_variance_mini=Nlmeans_flat_reprojection_mini(IB1,9,r1,seuil);
psnr_mini=psnr(estim_reproj_variance_mini,I)





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%                       TABLES          %%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  Computation time in function of R, searching window size   %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% sigma=10;
% [I,IB1 ]=genere_figure_bruit(20,sigma);
% w=9;
% r1=10;
% taille_p=num2str(w);
% R=num2str(2*r1+1);
% seuil=1/(w)^2*qchisq(0.99,(w)^2)*(2*sigma^2);
% for i=20:1024
% 
%     tic
%     [estim_reproj_variance,W]=Nlmeans_subsampling_matrice_variance_double(IB1(1:i,1:i),w,r1,seuil,1);
%     temps(i)=toc;
% end
% 
% hXLabel = 'Image Size';
% hYLabel = 'Time (s)';
% taille_font=19;
% taille_figure=[300,300, 1000, 600];
% figure_name='tps_nlwav';
% titre={'Time for NL - means   Wav-Reprojection',strcat(' neighborhood size= ',taille_p,'*',taille_p,', searching zone size=',R,'*',R , 'standard threshold')};
% fig_en=sortie_psnr_eps(20:1024,temps(20:1024),taille_figure,taille_font,'nb',titre,name_directory_win,figure_name,hXLabel,hYLabel);
% close all


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%%%%%%%%%%% Comparing  reprojections                   %%%%%%%%%%%%%        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        

noms={
'Barbara ';
'Boat    ';
'Bridge  ';
'Camera. ';
'Couple  ';
'Fingerp.';
'Flinst. '; 
'Hill    ';
'House   ';
'Lena    ';
'Man     ';
'Pepper  ';
'Av.     '};

rowLabels={
'Barbara ';
'Boats   ';
'Bridge  ';
'Camera. ';
'Couple  ';
'Fingerp.';
'Flinst. '; 
'Hill    ';
'House   ';
'Lena    ';
'Man     ';
'Peppers '
};

sigma=20;
w=9;
w1=4;
R=4;
h=1*sigma^2;

seuil_nl_means=100000;
w_big=9;
w_small=2;  
seuil1=1/(w_big)^2*qchisq(0.99,(w_big)^2)*(2*sigma^2);   
seuil2=1/(w_small)^2*qchisq(0.75,(w_small)^2)*2*sigma^2;    
bord=2;%%% 1: toric, 2:symmetric world

psnr_mean=zeros(12,1);
psnr_wav=zeros(12,1);
psnr_nl_central_gauss=zeros(12,1);
psnr_nl_central=zeros(12,1);
psnr_double_passe=zeros(12,1);



tic
for imag=1:12

    seuil_flat=1/(w)^2*qchisq(0.99,(w)^2)*(2*sigma^2); 
    [I,IB1]=genere_figure_bruit(imag,sigma);


    estim_mean=Nlmeans_flat_reprojection_uae(IB1,w,R,seuil_flat); 
    psnr_mean(imag)=psnr(double(estim_mean),double(I));


    estim_central=Nlmeans_flat(IB1,w1,R,seuil_flat,bord);
    psnr_nl_central(imag)=psnr(double(estim_central),double(I));
    

    estim_central_gauss=Nlmeans_original(IB1,w1,R,1/h,seuil_nl_means,bord);
    psnr_nl_central_gauss(imag)=psnr(double(estim_central_gauss),double(I));    

    [nl1,normalisation1]=Nlmeans_subsampling_matrice_variance_double(IB1,IB1,w_big,R,seuil1,1);
    psnr_wav(imag)=psnr(nl1,I);
            
    [nl2,normalisation2]=Nlmeans_subsampling_matrice_variance_double(IB1,IB1,w_small,R,seuil2,1);    
    estim_double_passe=(normalisation1/w_big.*nl1+nl2.*normalisation2/w_small)./(normalisation1/w_big+normalisation2/w_small);
    psnr_double_passe(imag)=psnr(double(estim_double_passe),double(I));
    
 

end
toc
psnr_tab=[psnr_nl_central,psnr_nl_central_gauss,psnr_mean,psnr_wav,psnr_double_passe]



nom_tableau=strcat('comp_reprojection','_patch',num2str(2*w+1),'*',num2str(2*w+1),'search',num2str(2*R+1),'*',num2str(2*R+1));

colLabels={'Flat','Gaussian','Flat Uae','Flat Wav','Double Wav'};

matrix2latex(psnr_tab,strcat(name_directory_win,'comp_all_reprojections','.tex'),'format','%.2f','rowLabels',noms,'columnLabels',{'flat','original','Uae','Wav','Wav Tso Size'})







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%%%%%%%   Psnr : Wav-reprojection with two size of patches    %%%%%%        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        


rowLabels={
'Barbara ';
'Boats   ';
'Bridge  ';
'Camera. ';
'Couple  ';
'Fingerp.';
'Flinst. '; 
'Hill    ';
'House   ';
'Lena    ';
'Man     ';
'Peppers '
};


sigma_tab=[5,10,20,50,100];
nb_sig=length(sigma_tab);
colLabels={'5','10','20','50','100'};

w_big=9;
w_small=2;
R=4;
r1=4
nb_im=12;



psnr_double_passe_flat=zeros(nb_im,5);



for sig=1:nb_sig

    sigma=sigma_tab(sig);
    seuil1=1/(w_big)^2*qchisq(0.99,(w_big)^2)*(2*sigma^2);   
    seuil2=1/(w_small)^2*qchisq(0.75,(w_small)^2)*2*sigma^2;    

    for imag=1:nb_im
        

        [I,IB1]=genere_figure_bruit(imag,sigma);
        [nl1,normalisation1]=Nlmeans_subsampling_matrice_variance_double(IB1,IB1,w_big,r1,seuil1,1); 
        [nl2,normalisation2]=Nlmeans_subsampling_matrice_variance_double(IB1,IB1,w_small,r1,seuil2,1);
        estim_double_passe=(normalisation1/w_big.*nl1+nl2.*normalisation2/w_small)./(normalisation1/w_big+normalisation2/w_small);    
        psnr_double_passe_flat(imag,sig)=psnr(estim_double_passe,I);
 

    end


end


psnr_tab=zeros(nb_im,nb_sig);


for i=1:nb_sig
    psnr_tab(:,i)=psnr_double_passe_flat(:,i);
    nom_tableau=strcat('nom_directe_double_passe','_patch','sigma=','5level','alpha2=75',num2str(w_big),'*',num2str(w_big),'search',num2str(2*R+1),'*',num2str(2*R+1));
end

matrix2latex(psnr_tab,strcat(name_directory_win,'comp_2sizes','.tex'),'format','%.2f','rowLabels',rowLabels,'columnLabels',{'flat','original','Uae','Wav','Wav Tso Size'})

close all




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  PSNR as a function of the size of the searching zone    %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%sigma=10;
%[I,IB1]=genere_figure_bruit(10,sigma);
%w=9;
%clear psnr_R
%taille_p=num2str(w);
%seuil=1/(w)^2*qchisq(0.99,(w)^2)*(2*sigma^2);
%h=sigma^2;
%psnr_R=zeros(50,1);
%
%for i=1:50
%    [estim_reproj_variance,W]=Nlmeans_subsampling_matrice_variance_double(IB1,IB1,w,i,seuil,1);
%    psnr_R(i)=psnr(double(I),double(estim_reproj_variance));
%end
%
%hXLabel = 'R1: radius of seraching zone';
%hYLabel = 'PSNR (dB)';
%taille_font=19;
%taille_figure=[300,300, 1000, 600];
%figure_name='PSNR_Rvariant_nlwav9';
%titre={'Time for NL - means   Wav-Reprojection',strcat(' neighborhood size= ',taille_p,'*',taille_p, 'standard threshold')};
%fig_en=sortie_psnr_eps(1:50,psnr_R,taille_figure,taille_font,'nb',titre,name_directory_win,figure_name,hXLabel,hYLabel);
%close all
