function fig_en=sortie_psnr_eps(x,y,taille_figure,taille_font,color,titre,name_directory_win,figure_name,hXLabel,hYLabel,legende)

%	x axis 
%	y to be plot
%	color= nb or couleur
%	legende= yes or no


%   Authors:  Salmon, Strozecki  
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NLM-Reprojections.
%
%   NLM-Reprojections is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NLM-Reprojections is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NLM-Reprojections.  If not, see
%   <http://www.gnu.org/licenses/>.

fig_en=figure('Name','fig_en','Position', taille_figure);


plot(x,y)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% 	    handle axes max/min		%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


v=axis;
v(3)=floor(min(min(y(:,:))))-1;
v(4)=ceil(max(max(y(:,:))))+1;

axis(v);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% 	    setting for color		%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

switch color
	case 'nb'
		set( 0, 'DefaultAxesColorOrder', [ 0 0 0] ) ;
		set(0,'DefaultAxesLineStyleOrder',{'-','-s','-o','-*',':',':s',':*',':o','--','--s','--o','--*'})

    case 'couleur'
		set( 0, 'DefaultAxesColorOrder', [1 0 0;0 1 0;0 0 1;0.5 0.5 0.5]) ;	
	
end





set(gca, ...
  'fontsize',taille_font, ...
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'on'      , ...
  'YMinorTick'  , 'on'      , ...
    'LineWidth'   , 1         );
% 'YGrid'       , 'on'      , ...
% 'XGrid'       , 'on'      , ...
% 'YTick'       , 0:500:2500, ...














%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% 	    handle axe string if name   %%%%%%%%%%%%%%%
%%%%%%%%%  	    of tick should be change 	%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 
% xt = get(gca,'xtick');
% % Suppress  corresponding labels
% set(gca,'xticklabel','','FontSize',taille_font);
% l=length(xt);
% 
% % Cas particulier si xt = 0
% idx = xt == 0;
% 
% % Create  good labels 
% str_axe = strcat(num2str(xt(:)),{'\sigma^2'});
% yl = ylim;
% yt = yl(2)-yl(1);
% text(xt,repmat(yl(1)-.05*yt,1,numel(xt)),str_axe,'hor','center','FontSize',taille_font);
% 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% 	    handle title                    %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%titre={strcat('  PSNR for varying R in the NL-means procedure (
%',strrep(patch_central,'_',' '),') '),strcat(' \sigma=',num2str(sigma),',
%S=',num2str(w),', optimised for \beta=',num2str(beta_min*pas_beta),'\sigma^2',':',num2str(pas_beta),'\sigma^2',':',num2str(beta_max*pas_beta),'\sigma^2')};
%titre={strcat('  PSNR for varying R in the NL-means procedure ( ',strrep(patch_central,'_',' '),') '),strcat(' sigma=',num2str(sigma),', S=',num2str(w),', optimised for beta=',num2str(beta_min*pas_beta),'sigma^2',':',num2str(pas_beta),'sigma^2',':',num2str(beta_max*pas_beta),'sigma^2')};
htitle=title(titre,'fontsize',taille_font);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% 	    handle meaning of the axes      %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


hXLabel = xlabel(hXLabel);
%hYLabel = ylabel('PSNR (dB)'                      );
hYLabel = ylabel(hYLabel);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% 	    handle legend                   %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%legende=nom_images;
if nargin > 10
hLegend=legend(legende,'Location','EastOutside');




set( gca                       , ...
    'FontName'   , 'Times' );
set([htitle, hXLabel, hYLabel,hLegend], ...
    'FontName'   , 'Times');
set([hLegend, gca]             , ...
    'FontSize'   , taille_font           );
set([hXLabel, hYLabel]  , ...
    'FontSize'   , taille_font          );
set( htitle                    , ...
    'FontSize'   , taille_font        );
   % 'FontWeight' , 'bold'      );
end
    




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% 	    handle exporting  nb          	%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




		filename_eps=strcat(name_directory_win,figure_name,'.eps');
		set(gcf, 'PaperPositionMode', 'auto');
          print('-deps','-r300', filename_eps);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% 	    handle exporting  nb          	%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 		figure_name=strcat('variation_R_pub','sigma',num2str(sigma),patch_central,'nb');
% 		filename_eps=strcat(name_directory_win,figure_name,'.eps');
% 		set(gcf, 'PaperPositionMode', 'auto');
%         print('-depsc2','-r300', filename_eps);
%         
        
        
