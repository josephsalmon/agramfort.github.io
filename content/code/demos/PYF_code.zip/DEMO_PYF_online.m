%% Simple example on Swoosh
%
% We present here the following neighboor filters
%  
% -LF: Linear filter 
% -YF: the Yaroslavky Filter 
% -NLM: Non Local Means 
% -Wavelet_cycle_denoising: wavelet thresholding (WARNING:rwt package required)
% -curveletdenoise: cuvelet denoising (WARNING:curvelet toolbox required)
% -YF_WaveletCycle_fast_precompute: Wavelet + YF (WARNING:rwt package required)
% -YF_WaveletCycle_fast_precompute: Curvelet + YF (WARNING:curvelet toolbox required)
% -YF_LF_fast_precompute: LF+YF 


% Rem: The kernel used is everywhere the box kernel. 
% See also README.TXT in the associate zip file for
% more details.
%
% See DEMO_PYF.m



%% Initialization
close all
clear all

% To be downloaded at: www.dsp.rice.edu/software/rice-wavelet-toolbox
addpath('rwt')
% the functions needed are: daubcqf.m, mrdwt.m, mirdwt.m, HardTh.m, 
% SoftTh.m

% To be downloaded at: www.curvelet.org
addpath('CurveletDenoise')
% the functions needed are: curveletdenoise.m, fdct_wrapping.m,
% fdct_wrapping_window.m, ifdct_wrapping.m
addpath('tools');
addpath('functions');

%% Build the true and noisy images
sigma=50;
ima = mean(double(imread('data/swoosh.png')),3);
ima_nse = ima + sigma * randn(size(ima));

%% Parameters initialization
param.search_width=21;% half width of the moving average
param.patch_width=7; %patch width
param.h_Yaro=sqrt(10*(sigma)^2);%
param.h_NLM=3.5*param.patch_width*param.patch_width*sigma^2;       
param.threshold_Wavelet=3.5*sigma;
param.threshold_WaveletCycle=3.5*sigma;
param.threshold_Curvelet=4.5*(sigma/255)^2;
param.h_NLMM=sqrt(0.4*sigma^2);
param.h_YF_Wavelet=sqrt(0.4*sigma^2);    
param.h_YF_Curvelet=sqrt(0.4*sigma^2);

%% Compute the different filters
ima_fil_LF=LF(ima_nse,param.patch_width);
ima_fil_YF=YF_yann(ima_nse,ima_nse,floor(param.search_width/2),param.h_Yaro);
ima_fil_Wav=Wavelet_cycle_denoising(ima_nse,param.threshold_WaveletCycle,0);
ima_fil_Curvelet=255*curveletdenoise(ima_nse/255,param.threshold_Curvelet,0,1);
ima_fil_NLM=NLM(ima_nse,floor(param.patch_width/2),floor(param.search_width/2),...
    param.h_NLM/(param.patch_width^2),2);
[ima_fil_YF_WaveletCycle,ima_fil_WaveletCycle]=YF_WaveletCycle_fast_precompute(...
    ima_nse,param.h_YF_Wavelet,param.search_width,param.threshold_WaveletCycle,0);     
[ima_fil_YF_Curvelet,ima_fil_Curvelet] = YF_Curvelet_fast_precompute(ima_nse,...
    param.h_YF_Curvelet,param.search_width,param.threshold_Curvelet,0,1);
ima_fil_NLMM=YF_LF_fast_precompute(ima_nse,param.h_NLMM,param.search_width,...
    param.patch_width);


%% Display result
figure('Position',[100 100  800 400])

subplot(2,4,1)
plotimage(ima_fil_LF);
title('Linear');
set(get(gca,'Title'),'FontSize',16);
subplot(2,4,2);
plotimage(ima_fil_YF);
title('Yaroslavsky');
set(get(gca,'Title'),'FontSize',16);
subplot(2,4,3);
plotimage(ima_fil_Wav);
title('Wavelet ');
set(get(gca,'Title'),'FontSize',16);
subplot(2,4,4);
plotimage(ima_fil_Curvelet);
title('Curvelet');
set(get(gca,'Title'),'FontSize',16);



subplot(2,4,5)
plotimage(ima_fil_NLM);
title('NLM ');
set(get(gca,'Title'),'FontSize',16);
subplot(2,4,6);
plotimage(ima_fil_YF_WaveletCycle);
title('Wavelet +YF');
set(get(gca,'Title'),'FontSize',16);
subplot(2,4,7);
plotimage(ima_fil_YF_Curvelet);
title('Curvelet +YF');
set(get(gca,'Title'),'FontSize',16);
subplot(2,4,8);
plotimage(ima_fil_NLMM);
title('LF+YF');
set(get(gca,'Title'),'FontSize',16);



linkaxes
