function Im_Wavelet = Wavelet_cycle_denoising(Im_noisy,threshold,type)

w = daubcqf(6);
[theta_l,theta_h] = mrdwt(Im_noisy,w);
switch type
    case 0

        theta_h = HardTh(theta_h,threshold);
    case 1

        theta_h = SoftTh(theta_h,threshold);
end


Im_Wavelet = mirdwt(theta_l,theta_h,w);
