function [Im_YF_Wavelet,Im_Wavelet] = YF_WaveletCycle_fast_precompute(Im_noisy,h,search_width,threshold,type)

half_search_widtdh=ceil(search_width/2);


%% Wavelet part
w = daubcqf(6);
[theta_l,theta_h] = mrdwt(Im_noisy,w);

switch type
    case 0

        theta_h = HardTh(theta_h,threshold);
    case 1

        theta_h = SoftTh(theta_h,threshold);
end


Im_Wavelet = mirdwt(theta_l,theta_h,w);
Im_YF_Wavelet = YF_yann(Im_noisy,Im_Wavelet,half_search_widtdh,h);

%  YF_fast_precompute(Im_noisy,Im_ori,half_search_widtdh,h,1);
