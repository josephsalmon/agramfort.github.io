function [Im_YF_LF,Im_LF] = YF_LF_fast_precompute(Im_noisy,h,search_width,patch_width)


half_search_widtdh=floor(search_width/2);
half_patch_widtdh=floor(patch_width/2);

Im_noisy_big = EdgeMirror(Im_noisy, [half_search_widtdh+half_patch_widtdh, half_search_widtdh+half_patch_widtdh]);
Im_LF_int = conv2(Im_noisy_big,ones(patch_width)/patch_width^2,'same');

Im_LF=Im_LF_int(half_search_widtdh+half_patch_widtdh+1:end-(half_search_widtdh+half_patch_widtdh),...
    half_search_widtdh+half_patch_widtdh+1:end-(half_search_widtdh+half_patch_widtdh));

Im_YF_LF = YF_yann(Im_noisy,Im_LF,half_search_widtdh,h);
