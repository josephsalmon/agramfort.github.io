function Im_LF = LF(Im_noisy,search_width)


half_search_widtdh=floor(search_width/2);

Im_noisy_big = EdgeMirror(Im_noisy, [half_search_widtdh, half_search_widtdh]);
Im_LF_int = conv2(Im_noisy_big,ones(search_width)/search_width^2,'same');

Im_LF=Im_LF_int(half_search_widtdh+1:end-(half_search_widtdh),...
    half_search_widtdh+1:end-(half_search_widtdh));
