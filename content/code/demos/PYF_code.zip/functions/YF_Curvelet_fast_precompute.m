function [Im_YF_Curvelet,Im_Curvelet] = YF_Curvelet_fast_precompute(Im_noisy,h,search_width,tau,type,highscalefactor)

half_search_widtdh=floor(search_width/2);
Im_Curvelet=255*curveletdenoise(Im_noisy./255,tau,type,highscalefactor);
% Im_YF_Curvelet =YF_fast(Im_Curvelet,Im_noisy,half_search_widtdh,h,2);


% Im_YF_Wavelet = YF_fast(Im_Wavelet,Im_noisy,half_search_widtdh,h,2);
Im_YF_Curvelet = YF_yann(Im_noisy,Im_Curvelet,half_search_widtdh,h);
