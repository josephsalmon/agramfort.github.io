function_options.evalCode=true;
function_options.stylesheet='/home/jo/Documents/Mes_papiers/CVJ/nlshape/trunk/code/Handlehtml/jsalmon.xsl';


% file_name=publish('DEMO_NLMSAP_gauss_cameraman',function_options);
% 
% cd html
% RENAMEFILE('DEMO_NLMSAP_gauss_cameraman.html', 'html','php')
% cd ..

file_name=publish('DEMO_NLMSAP_online',function_options);

cd html
RENAMEFILE('DEMO_NLMSAP_online.html', 'html','php')
cd ..
