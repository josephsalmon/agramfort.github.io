% FileSeries
% Version 1.50 02-Jun-2010
%
%   cdw               - Change directory (like CD), allowing wildcard (*).
%   lsw               - List directory (like LS), allowing wildcard (*).
%   rdir              - Recursive list directory.
%   rdelete           - Delete files recursively.
%   rrmdir            - Delete directories recursively.
%   renamefile        - Rename a series of files.
%   renumberfile      - Re-number the indices of a series of files
%   getfilenum        - Get the index of a series of files.
