Preprocessed Yaroslavsky Filter (PYF)
====================================

Revision:	        22/05/2011
Author:                 J. Salmon, R. Willet, E. Arias-Castro
Web page:               http://josephsalmon.eu/code/index_codes.php?page=PYF

PYF is a MATLAB software implementing the denoising algorithm Preprocessed
Yaroslavsky Filter (PYF) for images damaged by Gaussian noise
as presented in:

A two-stage denoising filter: the preprocessed Yaroslavsky filter
J. Salmon, R. Willett, E. Arias-Castro, SSP, 2012.


PYF is free software distributed under the GNU Public License
(GPL). PYF should be used only for nonprofit purposes. Any
unauthorized use of this software for industrial or profit-oriented
activities is expressively prohibited.

LICENSE
=======

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

See LICENSE.txt

HOW TO
======

The program has been written for MATLAB, and the packages
rwt for Wavelet, and curvelet  
 Please, look at DEMO_NLMLPR_online.m
to use the standard version of NLM, NLMA, YF, LF  and the (membership)
oracle (also called Oracle YF).

MAIN PROGRAM FILES
==================

The main program files are the following:

- DEMO_PYF_online.m: A demonstration file illustrating our denoising algorithms.

-LF: Linear filter 

-YF: the Yaroslavky Filter 

-NLM: Non Local Means 

-Wavelet_cycle_denoising: wavelet thresholding (WARNING:rwt package required)

-curveletdenoise: cuvelet denoising (WARNING:curvelet toolbox required)

-YF_WaveletCycle_fast_precompute: Wavelet + YF (WARNING:rwt package required)

-YF_WaveletCycle_fast_precompute: Curvelet + YF (WARNING:curvelet toolbox required)

-YF_LF_fast_precompute: LF+YF 



CONTACT INFORMATION
===================

For any comment, suggestion or question please contact Ery Arias-Castro
Joseph Salmon or Rebecca Willett.

Ery Arias-Castro		eariasca (at) ucsd.edu
Joseph Salmon			joseph.salmon (at) duke.edu
Rebecca Willett	                willett (at) duke.edu
Copyright (C) 2012 PYF project

See The GNU Public License (GPL) in LICENSE.txt

