function [denoised_golubev,weights_golubev,rhat_golubev]=Golubev(x,signal_size,sigma,alpha,w)

% Authors A. Dalalyan and J. Salmon

% input: 
% x:             input 1D signal coefficients
% x_Oracle:      true (non noisy) 1D signal coefficients
% signal_size:   length of the signal
% sigma:         std deviation of the noise
% alpha:         vector of alpha parameter in the Pinsker filter
% w:             vector of w     parameter in the Pinsker filter

% output
% denoised_golubev: denoised 1D signal coefficients unbiased risk estimation
% weight_golubev:   associated weights
% rhat_golubev      associated risk estimate

N=max(size(w));

mat_alpha=repmat(alpha,1,signal_size);
mat_w=repmat(w,1,signal_size);

weights_golubev_mat=repmat((1:signal_size),N,1);
weights_golubev_mat=max(0,1-(weights_golubev_mat.^mat_alpha./mat_w));

rep_Y=repmat(x,N,1);
rhat_golubev=sum((weights_golubev_mat.^2-2*weights_golubev_mat).*rep_Y.^2+2*sigma^2*weights_golubev_mat,2);


[min_value,min_index]=min(rhat_golubev);


weights_golubev=weights_golubev_mat(min_index,:);
denoised_golubev=x.*weights_golubev;
