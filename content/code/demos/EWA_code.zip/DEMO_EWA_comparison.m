%% Visual comparison between EWA and other procedures: DEMO_EWA_comparison.m
% This script displays the proposed denoising method used in the
% corresponding paper , for various 1D signals.
% The signals are first transformed using DCT and then denoised using 
% several methods of shrinkage, with or without aggregation
% (EWA, SS-ST, BJS, ORACLE). We consider one level of noise 
% with standard deviation \( \sigma=0.33\). See also README.TXT in the 
% associate zip file for more details.
%
% Authors:  \(\textbf{A. Dalalyan} \) and \( \textbf{J. Salmon} \)
%
%% Visualization of the original (non-noisy) signals considered
% Parameters initialization
%
all_signal={'Piece-Regular','Ramp','Piece-Polynomial','HeaviSine',...
    'Doppler','Blocks'};
font_size=19;
sigma=1;
signal_size=2^9;
figure_size=[100,100, 1000, 1000];
%%
% Display signals of interest
fig_signaux1=figure('Position', figure_size);
for i=1:6
    subplot(3,2,i)
    htitle={char(all_signal(i))};
    [X,Y,absci]=generate_signal(signal_size,char(...
        all_signal(i)),sigma);
    data_axis=[0 1 min(X)-0.2 max(X)+0.2];
    plot_article(fig_signaux1,absci,X,htitle,font_size,data_axis);
end


 
%% Visualization of the  denoised signals
smooth=0;
plot=1;
verb=0;
saving=0;

for i=1:6  
    sigma=0.33;
    launching_performance_fft(sigma,all_signal(i),...
        signal_size,smooth,verb,plot,saving);
end


