function []=tables_MSE(nb_simulations,sigma,smooth,signal_sizes,saving)

% input  :
% nb_simulations:    number of simulations performs
% sigma:             std deviation of the noise 
% smooth:            smooth=1 for smooth signal, zeros otherwise.

% output :
% create a latex tables in the current folder,
% for the six signals considered.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MSE Table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


max_signal_size=length(signal_sizes);

if saving==1
    my_path=pwd
    mkdir('./tables');
    my_path_table=strcat(my_path,'/tables/')
end

if smooth==0
    sm='';
else
    sm='smooth';
end

all_signal={'Blocks','Doppler','HeaviSine', 'Piece-Regular','Ramp','Piece-Polynomial'};
rowLabels1=signal_sizes;
rowLabels2=repmat({''},max_signal_size,1);
rowLabels=dedouble(cellstr(num2str(rowLabels1)),rowLabels2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MSE Blocks Doppler
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
choix=1;
signal_1=all_signal(choix);
signal_2=all_signal(choix+1);

table_MSE_1=zeros(max_signal_size,6,nb_simulations);
table_MSE_2=zeros(max_signal_size,6,nb_simulations);

tic
disp(['   ']);
disp(['   ** I use the version in Matlab directory']);
disp(['   ** starts experiments for Blocks and Doppler']);
for i=1:nb_simulations
    for j=1:max_signal_size
        signal_size=signal_sizes(j);        
        table_MSE_1(j,:,i)=launching_performance_fft(sigma,signal_1,signal_size,smooth,(rem(i,20)==0)*saving,0,saving);
        table_MSE_2(j,:,i)=launching_performance_fft(sigma,signal_2,signal_size,smooth,(rem(i,20)==0)*saving,0,saving);
    end
end

[mean_perf1,var_perf1]=compare_perf(signal_sizes,table_MSE_1,repmat(table_MSE_1(:,5,:),[1,6]));
perf1=dedouble_mat(mean_perf1,var_perf1);


[mean_perf2,var_perf2]=compare_perf(signal_sizes,table_MSE_2,repmat(table_MSE_2(:,5,:),[1,6]));
perf2=dedouble_mat(mean_perf2,var_perf2);


%% attention on a aussi calculer le mse noisy qu'on affiche pas à la fin 

if saving==1
    matrix2latex_article(perf1(:,1:end-2),perf2(:,1:end-2),char(strcat(my_path_table,signal_1,signal_2,'sigma',num2str(100*sigma),sm,'1.tex')),'format','%.3f','rowLabels',rowLabels)
end

if saving==0
    disp(['Difference of MSE between the method and the orcacle']);
    disp(['    EWA,    URE,     JSB,     SURE SHRINK,     ORACLE,     noisy ']);  
    perf1
    perf2
end


disp(['   ** experiments for Blocks and Doppler are finished in ' num2str(toc) ' seconds']);
disp(['   ']);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MSE HeaviSine, Piece-Regular
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
choix=3;
signal_3=all_signal(choix);
signal_4=all_signal(choix+1);

table_MSE_3=zeros(max_signal_size,6,nb_simulations);
table_MSE_4=zeros(max_signal_size,6,nb_simulations);

disp(['   ** starts experiments for HeaviSine and Piece-Regular']);
for i=1:nb_simulations
    
    for j=1:max_signal_size
  
        signal_size=signal_sizes(j);        
        table_MSE_3(j,:,i)=launching_performance_fft(sigma,signal_3,signal_size,smooth,(rem(i,20)==0)*saving,0,saving);
        table_MSE_4(j,:,i)=launching_performance_fft(sigma,signal_4,signal_size,smooth,(rem(i,20)==0)*saving,0,saving);
        

    end
end

[mean_perf3,var_perf3]=compare_perf(signal_sizes,table_MSE_3,repmat(table_MSE_3(:,5,:),[1,6]));
perf3=dedouble_mat(mean_perf3,var_perf3);



[mean_perf4,var_perf4]=compare_perf(signal_sizes,table_MSE_4,repmat(table_MSE_4(:,5,:),[1,6]));
perf4=dedouble_mat(mean_perf4,var_perf4);


%% attention on a aussi calculer le mse noisy qu'on affiche pas à la fin 
if saving==1
    matrix2latex_article(perf3(:,1:end-2),perf4(:,1:end-2),char(strcat(my_path_table,signal_3,signal_4,'sigma',num2str(100*sigma),sm,'1.tex')),'format','%.3f','rowLabels',rowLabels);
end
if saving==0
    disp(['Difference of MSE between the method and the orcacle']);
    disp(['    EWA,    URE,     JSB,     SURE SHRINK,     ORACLE,     noisy ']);  
    perf3
    perf4
end

disp(['   ** experiments for HeaviSine and Piece-Regular are finished in ' num2str(toc) ' seconds']);
disp(['  ']);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MSE 'Ramp','Sing'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
choix=5;
signal_5=all_signal(choix);
signal_6=all_signal(choix+1);

table_MSE_5=zeros(max_signal_size,6,nb_simulations);
table_MSE_6=zeros(max_signal_size,6,nb_simulations);


disp(['   ** starts experiments for Ramp and Piece-Polynomial']);
for i=1:nb_simulations
    for j=1:max_signal_size
        signal_size=signal_sizes(j);        
        table_MSE_5(j,:,i)=launching_performance_fft(sigma,signal_5,signal_size,smooth,(rem(i,20)==0)*saving,0,saving);
        table_MSE_6(j,:,i)=launching_performance_fft(sigma,signal_6,signal_size,smooth,(rem(i,20)==0)*saving,0,saving);
    end
end



[mean_perf5,var_perf5]=compare_perf(signal_sizes,table_MSE_5,repmat(table_MSE_5(:,5,:),[1,6]));
perf5=dedouble_mat(mean_perf5,var_perf5);

[mean_perf6,var_perf6]=compare_perf(signal_sizes,table_MSE_6,repmat(table_MSE_6(:,5,:),[1,6]));
perf6=dedouble_mat(mean_perf6,var_perf6);

%% saving the tables
if saving==1
    matrix2latex_article(perf5(:,1:end-2),perf6(:,1:end-2),char(strcat(my_path_table,signal_5,signal_6,'sigma',num2str(100*sigma),sm,'1.tex')),'format','%.3f','rowLabels',rowLabels)
end
if saving==0
    disp(['Difference of MSE between the method and the orcacle']);
    disp(['    EWA,    URE,     JSB,     SURE SHRINK,     ORACLE,     noisy ']);  
    perf5
    perf6
end

disp(['   ** The whole experiment is finished in ' num2str(toc) ' seconds']);



