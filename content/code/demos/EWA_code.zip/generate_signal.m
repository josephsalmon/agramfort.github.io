function [X,Y,abscissae]=generate_signal(N,signal_name,sigma)

% Authors A. Dalalyan and J. Salmon

%input
% N                     signal length
% signal_name           type of signal generated, eg. signal_name='Piece-Regular',
% 'Ramp' ,'Piece-Polynomial','HeaviSine', 'Doppler' ,'Blocks'
% sigma                 standard deviation of the noise added for Y


% output
% X              orginal (non-smooth) signal
% Y              noisy (non-smooth) signal with std deviation sigma
% abscissae      observation grid
   
X = MakeSignal(signal_name,N);
X=X./sqrt(mean(X.^2));
Y=X+sigma*randn(size(X));
abscissae=0:1/(N):(1-1/(N));
