function [denoised_golubev_oracle,weights_golubev_oracle,rhat_golubev_oracle]=Golubev_Oracle(x,x_Oracle,signal_size,sigma,alpha,w)

% Authors A. Dalalyan and J. Salmon

% input: 
% x:             input 1D signal coefficients
% x_Oracle:      true (non noisy) 1D signal coefficients
% signal_size:   length of the signal
% sigma:         std deviation of the noise
% alpha:         vector of alpha parameter in the Pinsker filter
% w:             vector of w     parameter in the Pinsker filter

% output
% denoised_golubev_oracle:   denoised 1D signal coefficients using oracle
% weight_golubev_oracle:            associated weights
% rhat_golubev_oracle        associated risk estimate


N=max(size(w));
mat_alpha=repmat(alpha,1,signal_size);
mat_w=repmat(w,1,signal_size);

weights_golubev_oracle_mat=repmat((1:signal_size),N,1);
weights_golubev_oracle_mat=max(0,1-(weights_golubev_oracle_mat.^mat_alpha./mat_w) );

rep_x=repmat(x_Oracle,N,1);

rhat_golubev_oracle=sum((1-weights_golubev_oracle_mat).^2.*rep_x.^2+sigma^2*weights_golubev_oracle_mat.^2,2);
[min_value,min_index]=min(rhat_golubev_oracle);
weights_golubev_oracle=weights_golubev_oracle_mat(min_index,:);
denoised_golubev_oracle=x.*weights_golubev_oracle;
