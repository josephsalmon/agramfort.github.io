=============================================================================
=        EWA :  Exponentially Weighted Agregates for regression             =
=                          README.txt Version 1.0                           =
=============================================================================
=    Copyright 2010, 2011                                                   =
=    Arnak Dalalyan*, Joseph Salmon**				            =
=        *  IMAGINE / CERTIS	 			                    =
=           Ecole des Ponts- ParisTech                                      =
=           6 Av Blaise Pascal -Cité Descartes                              =
=	    Champs-sur-Marne 						    =
=	    77455 Marne-la-Vallée Cedex 2- FRANCE			    =
=       **  LPMA / UMR 7599						    =
=	    Universtité Paris Diderot-Boîte courrier 7012                   =
=           75251 PARIS Cedex 05 (FRANCE)                                   =
=                                                                           =
=    Corresponding Author: Joseph Salmon      				    =
============================================================================= 



==========================================================================
================ 	      Overview              ======================
==========================================================================

We present some numerical experiments for regression with homoscedastic 
Gaussian noise with known variance. We evaluate different estimation routines
on 1D signals. We retained 6 signals for our experiments because
of their diversity. We have also carried out experiments on their 
smoothed versions obtained by taking an antiderivative. 
In both cases, prior to applying estimation routines, we 
normalize the (true) sampled signal to have an empirical norm equal to one.
We use the Discrete Cosine Transform (DCT) and shrink coefficient with 
several approaches.

The estimation routines, including the EWA, used in our experiments 
are detailed below:


	-Soft Thresholding (ST), Donoho and Johnstone (1994): 
	This is the soft-thresholding estimator of the vector of DCT 
	coefficients, with the  (fixed) universal threshold.  


	-SURE SHRINK (SS-ST) Donoho and Johnstone (1995):
	We use the soft-threshold method using the threshold minimizing the 
	estimated unbiased risk defined via Stein’s lemma.


	-Blockwise James-Stein (BJS) shrinkage, Cai (1999): 
	The set of indices {1,..., n} is partitioned into N =
	[n/ log(n)] non-overlapping blocks B_1, B_2,...,B_N of equal size L. 
	If n is not a multiple of N, the last block may be of smaller size 
	than all the others. The corresponding blocks of true coefficients 
	are estimated by shrinking the blocks of noisy coefficients. 
	The threshold parameter lambda used is lambda = 4.50524 
	as in Cai (1999).

	-Unbiased risk estimate (URE) minimization, Golubev (1992), 
	Cavalier et al. (2002): it consists in using a Pinsker filter, 
	with a data-driven choice of parameters alpha and w. This
	choice is done by minimizing an unbiased estimate of the risk over 
	a suitably chosen grid for the values of alpha and w. Here, we use 
	geometric grids ranging from 0.1 to 100 for alpha and from 1 to
	 n for w. The bi-dimensional grid used in all the experiments 
	has 100 × 100 elements. 


	-EWA on Pinsker’s filters: We consider the same finite family of 
	linear smoothers—defined by Pinsker’s filters—as in the URE routine 
	described above. This leads to an estimator which is nearly as 
	accurate as the	best Pinsker’s estimator in the given finite family.

	-ORACLE risk estimate minimization: it consists in 
	using a Pinsker filter, with an ORACLE choice of parameters 
	alpha and w. This choice is done by minimizing an the TRUE risk over 
	the same grid as for URE. This is the target method with which 
	we want to compare.




For more details, see
http://arxiv.org/pdf/???? 

To help users, we provide a few examples of our algorithm. To view a
demonstration, execute in MATLAB


>> DEMO_EWA_comparaison


NOTE:  These demonstration uses the idct and dct functions ( Discrete
Fourier Transform).  We include this two functions in the toolbox.

==========================================================================
================ 	   DEMO_EWA_comparaison         ==================
==========================================================================


Output:  This demonstration automatically displays the following:
        -The 6 (non Smooth) signals considered 
	-Their corresponding denoised version as described below.

This demonstration automatically creates the figure associated
with the Non smooth signals for one level of noise (sigma=0.1) 
and signals of size signal_size=2^9. This is done for the 6 images.
Top left are the original signal,
top right are the noisy versions, bottom left are the EWA (Pinsker) 
denoised signals, and bottom right are the Block James Stein method,
the URE and the SURE-Shrink Soft thresholding  (SS-ST) method. 



Copyright (2011): A. Dalalyan and J. Salmon

