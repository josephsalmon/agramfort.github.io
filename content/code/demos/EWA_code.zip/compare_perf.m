function [mean_diff,std_diff]=compare_perf(N,a,b)

% Authors A. Dalalyan and J. Salmon

% input
% N: signal size
% a,b: two 3D matrices to be compared.


% output
% mean_diff: mean of the difference between a and b
% std_diff:  std deviation of the difference between a and b


N=repmat(N,1,6);
mean_diff=N.*mean(a-b,3);
std_diff=N.*std(a-b,0,3);