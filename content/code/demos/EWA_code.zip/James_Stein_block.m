function [denoised_JS_block,weights_JS_block]=James_Stein_block(x,signal_size,block_size,sigma,lambda)

% Authors A. Dalalyan and J. Salmon

% input: 
% x:             input 1D signal coefficients
% signal_size:   length of the signal
% block_size:    size of the block used  
% sigma:         std deviation of the noise
% lambda:        thereshold parameter

% output
% denoised_JS_block:  denoised 1D signal coefficients with bloc James Stein method
% weights_JS_block:       associated weights



nb_block=floor(signal_size/block_size);
permutation=kron(eye(nb_block),ones(1,block_size));


[Y_mat,Poids_mat]=James_Stein(repmat(x(1:nb_block*block_size),nb_block,1).*permutation,nb_block*block_size,sigma,lambda*block_size);

denoised_JS_block_entier=sum(Y_mat,1);
weights_JS_block_entier=kron(Poids_mat',ones(1,block_size));

if signal_size>nb_block*block_size
    bords_coeff=x(1+nb_block*block_size:end);
    taille_bords=length(bords_coeff);
    [JS_bords,weights_JS_block_bords]=James_Stein(bords_coeff,taille_bords,sigma,lambda*taille_bords);

    JS_fin=sum(JS_bords,1);
    weights_JS_block_fin=kron(weights_JS_block_bords',ones(1,signal_size-block_size*nb_block));
    denoised_JS_block=[denoised_JS_block_entier JS_fin];
    weights_JS_block=[weights_JS_block_entier weights_JS_block_fin];
else
    
    % boundary
    denoised_JS_block=denoised_JS_block_entier;
    weights_JS_block=weights_JS_block_entier;
end



