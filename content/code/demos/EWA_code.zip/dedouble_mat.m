function interlaced=dedouble_mat(mat1,mat2)

% Authors A. Dalalyan and J. Salmon

% input
% mat1,mat2:  two matrices

% output
% interlaced: concatenation of the two matrices row1 mat1, row2 mat2,
% row3 mat1, row4 mat2 etc...

[m,n]=size(mat1);
interlaced=zeros(2*m,n);

if min(n,m)==1
    for i=1:max(m,n)
   
        interlaced(2*i-1)=mat1(i);    
        interlaced(2*i)=mat2(i);
    
    end
else

    for i=1:m

        interlaced(2*i-1,:)=mat1(i,:);
        interlaced(2*i,:)=mat2(i,:);

    end
end