function [denoised_soft_thresh, weight_soft_thresh]=soft_thresh(x,signal_size,sigma)

% Authors A. Dalalyan and J. Salmon

% input: 
% x:             input 1D signal coefficients
% signal_size:   length of the signal
% sigma:         std deviation of the noisy signal

% output
%denoised_soft_thresh:  denoised 1D signal coefficients
%weight_soft_thresh:    associated weights 


weight_soft_thresh=max(0,abs(x)-sigma*sqrt(log(signal_size)));
denoised_soft_thresh=weight_soft_thresh.*sign(x);