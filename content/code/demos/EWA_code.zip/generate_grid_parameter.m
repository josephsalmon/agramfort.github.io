function [alpha,w]=generate_grid_parameter(n,alpha_min,alpha_max,nb_alpha,w_min,w_max,nb_w)

% Authors A. Dalalyan and J. Salmon

% n:              1D signal length
% alpha_min:      min of th grid over alpha
% alpha_max:      maw of th grid over alpha
% nb_alpha:       numbers or steps in the discretization of the alpha grid
% w_min:          min of th grid over w
% w_max:          max of th grid over w
% nb_w:           numbers or steps in the discretization of the w grid

if (nargin==1)
    alpha_min=.1;
    alpha_max=100;
    nb_alpha=100;
    w_min=1;
    w_max=n;
    nb_w=100;
end


alpha=exp(log(alpha_min):(log(alpha_max)-log(alpha_min))/nb_alpha:log(alpha_max)-(log(alpha_max)-log(alpha_min))/nb_alpha);
w=exp(log(w_min):(log(w_max)-log(w_min))/nb_w:log(w_max)-(log(w_max)-log(w_min))/nb_w);

alpha=kron(ones(nb_w,1),alpha');
w=kron(w',ones(nb_alpha,1));

