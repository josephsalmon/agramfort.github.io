function [denoised_pinsker,weight_pinsker,rep_x,trace_mat]=pinsker(x,signal_size,alpha,w)

% Authors A. Dalalyan and J. Salmon

% input: 
% x:             input 1D signal coefficients
% signal_size:   length of the signal
% alpha:         vector of alpha parameter in the Pinsker filter
% w:             vector of w     parameter in the Pinsker filter

% output
% denoised_sure_shrink:  denoised 1D signal coefficients
% weight_pinsker:        associated weights 
% rep_x:                 signal replicated
% trace_mat:             trace matrix of the estimator


nb_samples=length(alpha);
mat_alpha=repmat(alpha,1,signal_size);
mat_w=repmat(w,1,signal_size);

weight_pinsker=repmat((1:signal_size),nb_samples,1);
weight_pinsker=max(0,1-(weight_pinsker).^mat_alpha./(mat_w.*signal_size.^(mat_alpha./(2.*mat_alpha+1) ))); 

trace_mat=sum(weight_pinsker,2);
rep_x=repmat(x,nb_samples,1);
denoised_pinsker=rep_x.*weight_pinsker;

