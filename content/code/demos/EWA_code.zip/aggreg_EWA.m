function [aggregated_EWA,weight_EWA]=aggreg_EWA(fhat,rhat,beta)

% Authors A. Dalalyan and J. Salmon

% input: 
% fhat:          estimators to aggregate
% rhat:          corresponding risks estimates
% beta:          temperature parameter


% output
% aggregated_EWA: denoised 1D signal coefficients unbiased risk estimation
% weight_EWA:     associated weights



rhat_min=min(rhat);

weight_EWA=exp(-(rhat-rhat_min)/beta);
weight_EWA=weight_EWA./sum(weight_EWA);

aggregated_EWA=weight_EWA'*fhat;