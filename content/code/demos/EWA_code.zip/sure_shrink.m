function [denoised_sure_shrink,weight_sure_shrink,rhat_sure_shrink]=sure_shrink(x,signal_size,sigma,alpha_min,alpha_max,nb_alpha)

% input: 
% x:             input 1D signal coefficients
% signal_size:   length of the signal
% sigma:         std deviation of the noisy signal
% alpha_min:     min of the (logarithmic) grid for the parameter alpha
% alpha_max:     max of the (logarithmic) grid for the parameter alpha
% nb_alpha:      number of elements of the grid for the parameter alpha


% output
%denoised_sure_shrink:  denoised 1D signal
%weight_sure_shrink:    associated weights 
%rhat_sure_shrink:      estimation of the risk



alpha =alpha_min:(alpha_max-alpha_min)/nb_alpha:alpha_max-(alpha_max-alpha_min)/nb_alpha;
alpha_mat=repmat(alpha',1,signal_size);


x_mat=repmat(x,nb_alpha,1);
abs_x=abs(x_mat);
nb_choosen=sum(abs_x<alpha_mat,2);
rhat_sure_shrink=-2*sigma^2*nb_choosen+sum( (min(abs_x,alpha_mat)).^2,2);


[min_value,min_index]=min(rhat_sure_shrink);
weight_sure_shrink=max(0,abs(x)-alpha(min_index));
denoised_sure_shrink=weight_sure_shrink.*sign(x);



