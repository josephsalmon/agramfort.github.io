function table_MSE=launching_performance_fft(sigma,signal,signal_size,smooth,verb,plot,saving)

% Authors A. Dalalyan and J. Salmon

% input
% sigma : std deviation of the noise
% signal: name of the signal used
% signal_size: signal size
% smooth: 1 if using the (true) signal generated is smoothed, 0 otherwise
% verb: 1 if one needs the comments to appear (1 is default)
% plot: 1 if one wants the signal to be ploted

% output
% table_MSE: matrix of the Mean Square Error, each column represents one method
% in order EWA,Golubev,JS-block,sure_shrink,Golubev_Oracle,noisy

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

s=RandStream('shr3cong','Seed', 0);
RandStream.setDefaultStream(s)

RandStream.setDefaultStream ...
(RandStream('mt19937ar','seed',sum(100*clock)));
 
beta=8*sigma^2;
w=floor(signal_size/10);
alpha=2;
size_block=floor(log(signal_size));
lambda=4.50524; % cf block thresholding and oracle inequality T.Cai 99
alpha_min=.1;
alpha_max=100;
nb_alpha=100;
w_min=1;
w_max=signal_size;
nb_w=100;
nb_samples=nb_alpha*nb_w;

[alpha,w]=generate_grid_parameter(signal_size,alpha_min,alpha_max,nb_alpha,w_min,w_max,nb_w);

switch smooth
    case 0
        [X,Y,abscissae]=generate_signal(signal_size,signal,sigma);
    case 1
        [X,Y,abscissae]=generate_smooth_signal(signal_size,signal,sigma);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% fourier
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
wc=dct(Y);

wc_Oracle=dct(X);
wc_Oracle_s=wc_Oracle/sqrt(signal_size);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% various diagonal term by term operator
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%soft thresholding
[coeff_soft_thresh,poids_soft_thresh]=soft_thresh(wc,signal_size,sigma);
hat_x_soft_thresh=idct(coeff_soft_thresh);

%% SURE Shrink
alpha_min_sure_shrink=0;
alpha_max_sure_shrink=4*sigma*sqrt(2*log(signal_size));
[coeff_sure_shrink,poids_sure_shrink]=sure_shrink(wc,signal_size,sigma,alpha_min_sure_shrink,alpha_max_sure_shrink,nb_samples);
hat_x_sure_shrink=idct(coeff_sure_shrink);


%disp('   *        URE: ' );
%%Golubev URE
[coeff_golubev,poids_golubev,rhat_golubev]=Golubev(wc,signal_size,sigma,alpha,w);
hat_x_golubev=idct(coeff_golubev);


%%Golubev URE - Oracle
[coeff_golubev_Oracle,poids_golubev_Oracle,rhat_golubev_Oracle]=Golubev_Oracle(wc,wc_Oracle,signal_size,sigma,alpha,w);
hat_x_golubev_Oracle=idct(coeff_golubev_Oracle);


%%JamesStein Block
[coeff_JSblock,poids_JSblock]=James_Stein_block(wc/sqrt(signal_size),signal_size,size_block,sigma/sqrt(signal_size),lambda);
hat_x_JSblock=idct(coeff_JSblock*sqrt(signal_size));


%disp('   *        EWA: ' );
%%EWA 
[coeff_EWA,poids_EWA,alpha_EWA,w_EWA]=EWA(wc,signal_size,sigma,beta,alpha,w);
hat_x_EWA=idct(coeff_EWA);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% MSE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
MSE_noisy=mean((Y-X).^2);
MSE_JSblock=mean((hat_x_JSblock-X).^2);
MSE_EWA=mean((hat_x_EWA-X).^2);
MSE_Golubev=mean((hat_x_golubev-X).^2);
MSE_Golubev_Oracle=mean((hat_x_golubev_Oracle-X).^2);
MSE_soft_thresh=mean((hat_x_soft_thresh-X).^2);
MSE_sure_shrink=mean((hat_x_sure_shrink-X).^2);
 
if verb==1
    disp(['        Sigma: ' num2str(sigma) '  ---  Signal size:   ' num2str(signal_size) ]);
    disp(['   *    MSE_soft_thresh: ' num2str(MSE_soft_thresh)]);
    disp(['   *    MSE_SURE_SHRINK: ' num2str(MSE_sure_shrink)]);
    disp(['   *        MSE_JSblock: ' num2str(MSE_JSblock)]);
    disp(['   *        MSE_Golubev: ' num2str(MSE_Golubev)]);
    disp(['   * MSE_Golubev_Oracle: ' num2str(MSE_Golubev_Oracle)]);
    disp(['   *            MSE_EWA: ' num2str(MSE_EWA)]);

    disp(['   ----------------------------------' ]);
    disp(['   ----------------------------------' ]);
    disp(['   ' ]);
end;

risks=[MSE_noisy MSE_JSblock MSE_EWA MSE_Golubev MSE_Golubev_Oracle MSE_sure_shrink];

PSNR=10*log10(max(X)^2./risks);
PSNR=round(100*PSNR)/100;

table_MSE=[MSE_EWA,MSE_Golubev,MSE_JSblock,MSE_sure_shrink,MSE_Golubev_Oracle,MSE_noisy];

if plot==1
    font_size=19;
    figure_size=[100,100, 1700, 900];
    data_axis=[0 1 min(Y) 1.3*max(Y)];
    fig_signaux2=figure('Name','fig_signaux2','Position', figure_size);


    subplot(2,2,1)
    htitle={strcat('Signal Length: n=',num2str(signal_size))};
    plot_article(fig_signaux2,abscissae,X,htitle,font_size,data_axis);

    subplot(2,2,2)
    htitle={strcat('Noisy function : \sigma=',num2str(sigma), ' and PSNR=',num2str(PSNR(1)))};
    plot_article(fig_signaux2,abscissae,Y,htitle,font_size,data_axis);


    subplot(2,2,3)
    htitle=strcat('Denoised by EWA (PSNR=',num2str(PSNR(3)),')');
    plot_article(fig_signaux2,abscissae,hat_x_EWA,htitle,font_size,data_axis);

    subplot4=subplot(2,2,4);
    htitle={['Denoised by BJS (PSNR=' num2str(PSNR(2)) ') URE (PSNR=' num2str(PSNR(4)) '), SS-ST (PSNR=' num2str(PSNR(6)) ')']};
    affichage=plot_article(fig_signaux2,abscissae,[hat_x_JSblock;hat_x_golubev;hat_x_sure_shrink],htitle,font_size,data_axis);
    set(affichage(2),'Color',[1 0 0]);
    set(affichage(3),'Color',[0 0 1],'LineStyle','--');
    legend({'BJS','URE', 'SS-ST'},'FontSize',font_size,'FontName', 'Arial');
    legend1 = legend(subplot4);
    set(legend1,'Location','NorthEast');
    linkaxes;
    
    if saving==1

        saveas(gcf,char(strcat('./figures/',signal,num2str(signal_size),'sigma',num2str(100*sigma))),'fig')
        saveas(gcf,char(strcat('./figures/',signal,num2str(signal_size),'sigma',num2str(100*sigma))),'pdf')
    end
end