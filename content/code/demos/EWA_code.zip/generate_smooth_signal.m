function [X,Y,abscissae]=generate_smooth_signal(N,signal_name,sigma)

% Authors A. Dalalyan and J. Salmon

%input
% N                     signal length
% signal_name           type of signal generated, eg. signal_name='Piece-Regular',
% 'Ramp' ,'Piece-Polynomial','HeaviSine', 'Doppler' ,'Blocks'
% sigma                 standard deviation of the noise added for Y


% output
% X              orginal (smooth) signal
% Y              noisy (smooth) signal with std deviation sigma
% abscissae      observation grid
   
M=2^18;
Z = MakeSignal(signal_name,M);
M=max(size(Z));
Z=Z/sqrt(mean(Z.^2));
Z=idct(dct(Z)./(1:M));
K=(M/N);
X=Z(round((1:N)*K));
X=X./sqrt(mean(X.^2));
Y=X+sigma*randn(size(X));
abscissae=0:1/(N):(1-1/(N));
