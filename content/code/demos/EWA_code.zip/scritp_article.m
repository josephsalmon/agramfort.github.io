
% Authors A. Dalalyan and J. Salmon

% this script provides the results given in the article...
% it consisit in denoising using the dct several kind of singal referenced
% just below. It provide graphical outputs (.fig) and tables (.tex)



all_signal={'Piece-Regular','Ramp','Piece-Polynomial','HeaviSine',...
    'Doppler','Blocks'};


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% display 6 signals
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

font_size=16;
taille_figure=[100,100, 1000, 1000];
sigma=1;
signal_size=2^9;
saving=1;

fig_signaux2=figure('Name','fig_signaux2','Position', taille_figure);

for i=1:6
    subplot(3,2,i)
    htitle={char(all_signal(i))};
    [X,Y,abscissae]=generate_signal(signal_size,char(all_signal(i)),...
        sigma);
    data_axis=[0 1 min(X)-0.2 max(X)+0.2];
    plot_article(fig_signaux2,abscissae,X,htitle,font_size,data_axis);
end
mkdir('figures')
name=char(strcat('./figures/','true_signal'));
saveas(gcf,nom,'fig')

fig_signaux2=figure('Name','fig_signaux2','Position', taille_figure);

for i=1:6    
    subplot(3,2,i)
    htitle={char(all_signal(i))};
    [X,Y,abscissae]=generate_smooth_signal(signal_size,...
        char(all_signal(i)),sigma);
    X=X-mean(X);
    data_axis=[0 1 min(X)-0.2 max(X)+0.2];
    plot_article(fig_signaux2,abscissae,X,htitle,font_size,data_axis);
end

if saving==1

    name_smooth=char(strcat('./figures/','true_signal_lisse'));
    saveas(gcf,name_smooth,'fig')
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% denoising the 6 signal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
smooth=0;
plot=1;
verb=1;
saving=1;
for i=1:6  
    sigma=0.33;
    launching_performance_fft(sigma,all_signal(i),signal_size,smooth,verb,plot,saving)
        
    sigma=0.1;
    launching_performance_fft(sigma,all_signal(i),signal_size,smooth,verb,plot,saving)
   
    sigma=1;
    launching_performance_fft(sigma,all_signal(i),signal_size,smooth,verb,plot,saving)
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MSE Table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
signal_sizes=2.^[8:11]';
saving=1;
tables_MSE(20^2,0.33,0,signal_sizes,saving);
tables_MSE(20^2,0.33,1,signal_sizes,saving);
