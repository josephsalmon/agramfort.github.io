function affichage=plot_article(current_fig,abscissae,X,htitle,font_size,data_axis)

% Authors A. Dalalyan and J. Salmon

%input:
% current_fig:  current figure
% abscissae:    absissae for ploting 
% htitle:       title of the figure
% X:            signal to plot
% font_size:    font size used in the plot
% data_axis:    axis of the figure

affichage=plot(abscissae,X,'LineWidth',1);
axis(data_axis)

set(gca, ...
  'fontsize',font_size, ...
  'XMinorTick'  , 'on'      , ...
  'YMinorTick'  , 'on'      , ...
    'LineWidth'   , 1         );

set(gca, ...
    'FontName'   , 'Times' );
title(htitle,'FontName', 'Times','FontSize',font_size);
