function [denoised_JS,weights_JS]=James_Stein(x,signal_size,sigma,lambda)

% Authors A. Dalalyan and J. Salmon

% input: 
% x:             input 1D signal coefficients
% signal_size:   length of the signal
% sigma:         std deviation of the noise
% lambda:        thereshold parameter

% output
% denoised_JS:  denoised 1D signal coefficients with bloc James Stein method
% weights_JS:       associated weights

weights_JS=max(0,1-lambda*sigma^2./sum(x.^2,2));
denoised_JS=x.*repmat(weights_JS,1,signal_size);
