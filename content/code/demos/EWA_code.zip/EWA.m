function [denoised_EWA,weights_EWA,alpha,w]=EWA(x,signal_size,sigma,beta,alpha,w)

% Authors A. Dalalyan and J. Salmon

% input: 
% x:             input 1D signal coefficients
% signal_size:   length of the signal
% sigma:         std deviation of the noise
% beta:          temperature parameter
% alpha:         vector of alpha parameter in the Pinsker filter
% w:             vector of w     parameter in the Pinsker filter

% output
% denoised_EWA: denoised 1D signal coefficients unbiased risk estimation
% weight_EWA:   associated weights


if nargin==4
    [alpha,w]=genere_parametre2(signal_size);
end

[fhat,poids,rep_Y,trace_mat]=pinsker(x,signal_size,alpha,w);    
rhat=(sum(abs( rep_Y-fhat).^2,2)./signal_size+...
    2*trace_mat*sigma^2./signal_size-sigma^2)*signal_size;
[denoised_EWA,weights_EWA]=aggreg_EWA(fhat,rhat,beta);
weights_EWA=weights_EWA'*poids;
